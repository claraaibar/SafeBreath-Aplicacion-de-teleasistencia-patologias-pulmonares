package control;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class MenuPrincipalControllerDB {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button boton_login_vp;

    @FXML
    private Button boton_registro_vp;

    @FXML
    void cambiar_ventana_login(ActionEvent event) {
    	try {
//    		
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_login.fxml"));
    		
    		LoginDB control = new LoginDB();
    		
    		loader2.setController(control);

    		Parent root = loader2.load();
    		
    		Scene scene = new Scene(root);
    		Stage stage = new Stage();
    		
    		stage.setScene(scene);
    		stage.show();
    		
    		 Stage stage2 = (Stage) this.boton_login_vp.getScene().getWindow();
    	     stage2.close();
    		
    		
    		}
    		catch(Exception e) {
    			e.printStackTrace();
    		}	
    	//Aqui hace falta poner una ventana nueva que tenga para meter un usuario y contrasena y se conecte con la clase LoginDB
    }

    @FXML
    void cambiar_ventana_registro(ActionEvent event) {
    	try {
     		 
       		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_registro_medico.fxml"));
       		
       		RegistroMedicoControllerDB control = new RegistroMedicoControllerDB();
       		
       		loader2.setController(control);

       		Parent root = loader2.load();
       		
       		Scene scene = new Scene(root);
       		Stage stage = new Stage();
       		
       		stage.setScene(scene);
       		stage.show();
       		
       		Stage stage2 = (Stage) this.boton_registro_vp.getScene().getWindow();
       		stage2.close();
    		
       		}
       		catch(Exception e) {
       			e.printStackTrace();
       		}


    }

    @FXML
    void initialize() {
        assert boton_login_vp != null : "fx:id=\"boton_login_vp\" was not injected: check your FXML file 'LOGIN RESPONSIVE.fxml'.";
        assert boton_registro_vp != null : "fx:id=\"boton_registro_vp\" was not injected: check your FXML file 'LOGIN RESPONSIVE.fxml'.";

    }

	public Object closeWindows() {
		// TODO Auto-generated method stub
		return null;
	}

}

