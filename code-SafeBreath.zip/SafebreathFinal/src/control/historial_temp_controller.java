package control;


import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.time.LocalDate;
import java.util.Vector;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.sun.javafx.scene.control.skin.FXVK.Type;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.stage.Stage;
import model.Paciente;


import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class historial_temp_controller {
//  Database credentials
		static final String USER = "prb_SafeBreath";
		static final String PASS = "camaleon";

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea text_imprimir_temp;

    @FXML
    private LineChart<String, Double> graf_temp;
    
    
    @FXML
    void mostrar_temp(ActionEvent event) {
    
    Connection conn = null;
	Statement stmt = null;
	String sql;
	try {
		//STEP 1: Register JDBC driver
		Class.forName("org.mariadb.jdbc.Driver");
		//STEP 2: Open a connection
		try {
			conn = DriverManager.getConnection(
					"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//consulta
			sql = "SELECT * FROM Temperatura JOIN paciente USING (id_P) WHERE paciente.id_P= Temperatura.id_P AND 21=Temperatura.id_P";

			System.out.println("sql command: "+ sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			System.out.println(rs);
			int temperatura = 0;
			Timestamp timestamp = null;
			String antiguo = null;
			String nuevo = null;
			
			
			
			//int Tipo = 0;

			while( rs.next() ) {

				temperatura = rs.getInt("temperatura");
				timestamp = rs.getTimestamp("tiempoRegistroT");

				antiguo = nuevo;
				nuevo = antiguo  + temperatura +"\t" + "\t"+ timestamp +"\n" ;
			}       
			text_imprimir_temp.setText(nuevo);
			rs.close();
			stmt.close();
			//System.out.println(Tipo);
			//return Tipo;
		}catch(Exception e){
			e.printStackTrace();
			System.out.println("Se ha producido un error ");
		}    

		conn.close();
	} catch (SQLException se) {   
		se.printStackTrace();
	} catch (Exception e) {  
		e.printStackTrace();
	} finally {  
		try {
			if (stmt != null) {conn.close();}
		} catch (SQLException se) { }
		try {
			if (conn != null) {conn.close();}
		} catch (SQLException se) { se.printStackTrace();
		}
	}
	return;
    
    }
    
    private void graf_temp(double parametro, String nombre) {
      	
      	//grafica.getData().clear();
      	
      	Series<String,Double> series = new XYChart.Series<>();
      	series.setName(nombre);
      	
      	series.getData().add(new XYChart.Data<>(nombre,parametro));
      	graf_temp.getData().add(series);
      }

    @FXML
    void mostrar_temp2(ActionEvent event) {
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM Temperatura JOIN paciente USING (id_P) WHERE paciente.id_P= Temperatura.id_P AND 21=Temperatura.id_P";
						

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				int temperatura;
				Timestamp tiempo;

			

				while( rs.next() ) {

					temperatura = rs.getInt("temperatura");
					tiempo = rs.getTimestamp("tiempoRegistroT");
					System.out.println(temperatura);
					
					System.out.println("holi");
					System.out.println(tiempo);
					graf_temp(temperatura,String.valueOf(tiempo));
					
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			
			
			}
		}
    }

    @FXML
    void initialize() {
        assert text_imprimir_temp != null : "fx:id=\"text_imprimir_temp\" was not injected: check your FXML file 'vista_historial_temperatura.fxml'.";
        assert graf_temp != null : "fx:id=\"graf_temp\" was not injected: check your FXML file 'vista_historial_temperatura.fxml'.";

    }
}
