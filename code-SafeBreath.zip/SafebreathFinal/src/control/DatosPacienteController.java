package control;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.TextField;

public class DatosPacienteController {

//  Database credentials
	static final String USER = "prb_SafeBreath";
	static final String PASS = "camaleon";

    @FXML
    private LineChart<String, Double> graf_frec_card;

    @FXML
    private LineChart<?, ?> graf_frec_resp;

    @FXML
    private LineChart<?, ?> graf_la_que_falta;

    @FXML
    private LineChart<String, Double> graf_temp;

    @FXML
    private TextField textF_apellido;

    @FXML
    private TextField textF_dni;

    @FXML
    private TextField textF_fn;

    @FXML
    private TextField textF_genero;

    @FXML
    private TextField textF_nombre;

  private void graf_frec_card(double parametro, String nombre) {
    	
    	//grafica.getData().clear();
    	
    	Series<String,Double> series = new XYChart.Series<>();
    	series.setName(nombre);
    	
    	series.getData().add(new XYChart.Data<>(nombre,parametro));
    	graf_frec_card.getData().add(series);
    }
  
  private void graf_temp(double parametro, String nombre) {
  	
  	//grafica.getData().clear();
  	
  	Series<String,Double> series = new XYChart.Series<>();
  	series.setName(nombre);
  	
  	series.getData().add(new XYChart.Data<>(nombre,parametro));
  	graf_temp.getData().add(series);
  }
  
    @FXML
    void mostrar_frec_card(ActionEvent event) {
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM FrecResp JOIN paciente USING (id_P) WHERE paciente.id_P= FrecResp.id_P AND 1=FrecResp.id_P";
						

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				int frecresppac;
				Timestamp timestamp;
				


				int ignacioestonto = 0;

				while( rs.next() ) {

					frecresppac = rs.getInt("frecuResp");
					timestamp = rs.getTimestamp("tiempoRegistroF");
					
					System.out.println(frecresppac);	
					System.out.println("holi");
					System.out.println(timestamp);
					graf_frec_card(frecresppac,String.valueOf(timestamp));
					
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			
			
			}
		}

    }

    @FXML
    void mostrar_frec_resp(ActionEvent event) {

    }

    @FXML
    void mostrar_temp(ActionEvent event) {
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM Temperatura JOIN paciente USING (id_P) WHERE paciente.id_P= Temperatura.id_P AND 21=Temperatura.id_P";
						

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				int temperatura;
				Timestamp tiempo;

			

				while( rs.next() ) {

					temperatura = rs.getInt("temperatura");
					tiempo = rs.getTimestamp("tiempoRegistroT");
					System.out.println(temperatura);
					
					System.out.println("holi");
					System.out.println(tiempo);
					graf_temp(temperatura,String.valueOf(tiempo));
					
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			
			
			}
		}
    }

    
    @FXML
    void initialize() {
        
    	
    	textF_nombre.setText(LoginDB.usuarioN[0]);
        textF_apellido.setText(LoginDB.usuarioN[1]);
        textF_dni.setText(LoginDB.usuarioN[2]);
        textF_genero.setText(LoginDB.usuarioN[3]);
        textF_fn.setText(LoginDB.usuarioN[4]);
        
        assert graf_temp != null : "fx:id=\"graf_temp\" was not injected: check your FXML file 'vista_graficas_paciente.fxml'.";
        assert graf_frec_card != null : "fx:id=\"graf_frec_card\" was not injected: check your FXML file 'vista_graficas_paciente.fxml'.";
        assert graf_la_que_falta != null : "fx:id=\"graf_la_que_falta\" was not injected: check your FXML file 'vista_graficas_paciente.fxml'.";
        assert graf_frec_resp != null : "fx:id=\"graf_frec_resp\" was not injected: check your FXML file 'vista_graficas_paciente.fxml'.";

    }
    
}

