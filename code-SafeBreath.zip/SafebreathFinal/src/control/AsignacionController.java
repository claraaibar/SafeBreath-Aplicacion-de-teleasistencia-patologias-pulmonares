package control;

	import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
	import javafx.event.ActionEvent;
	import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
	import javafx.scene.control.TextArea;
	import javafx.scene.control.TextField;
import javafx.stage.Stage;

	
	public class AsignacionController {
		

	//  Database credentials
		static final String USER = "prb_SafeBreath";
		static final String PASS = "camaleon";

	    @FXML
	    private ResourceBundle resources;

	    @FXML
	    private URL location;

	    @FXML
	    private Button boton_listar_cuidadores;

	    @FXML
	    private Button boton_volver;

	    @FXML
	    private TextArea textarea_listar_cuidadores;

	    @FXML
	    private Button boton_listar_pacientes;

	    @FXML
	    private TextArea textarea_listar_pacientes;

	    @FXML
	    private TextField textfield_dni_cuidador;

	    @FXML
	    private TextField textfield_dni_paciente;

	    @FXML
	    private Button boton_asignar;

	    @FXML
	    void asiganr(ActionEvent event) {

	    	String dniP = textfield_dni_paciente.getText();
	    	
	    	String dniC = textfield_dni_cuidador.getText();
	    	
	    	Connection conn = null;
			Statement stmt = null;
			String sql;
			try {
				//STEP 1: Register JDBC driver
				Class.forName("org.mariadb.jdbc.Driver");
					conn = DriverManager.getConnection(
							"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

					//consulta
					sql = "SELECT id_P FROM paciente WHERE paciente.DNI = \""+ dniP + "\"";

					stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery( sql );
					String idP = null;
					while( rs.next() ) {

						idP = rs.getString("id_P");
					}
					if(idP != null) {
						
						try {
							
							Class.forName("org.mariadb.jdbc.Driver");
							conn = DriverManager.getConnection(
									"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

							//consulta
							sql = "SELECT id_C FROM cuidador WHERE cuidador.DNI = \""+ dniC + "\"";

							stmt = conn.createStatement();
							rs = stmt.executeQuery( sql );
							String idC = null;
							while( rs.next() ) {

								idC = rs.getString("id_C");
							}
							if (idC != null) {
								
								try {
									Class.forName("org.mariadb.jdbc.Driver");
									conn = DriverManager.getConnection("jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
									System.out.println("Connectado a la Base de Datos...");
									

									sql = "Insert into Supervisa(id_P, id_C) values('"+idP+"','"+idC+"');"; //el first es del valor de la tabla first name"
									System.out.println("sql Insert: "+sql);
									stmt = conn.createStatement(); 
									stmt.executeUpdate(sql);  
									stmt.close();
									
								} catch (SQLException se) {
									//Handle errors for JDBC
									se.printStackTrace();
								} catch (Exception e) {
									//Handle errors for Class.forName
									e.printStackTrace();
								}
								try {
						    		
						    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_medico_opcional.fxml"));
						    		
						    		MenuMedicoController2 control = new MenuMedicoController2();
						    		
						    		loader2.setController(control);

						    		Parent root = loader2.load();
						    		
						    		Scene scene = new Scene(root);
						    		Stage stage = new Stage();
						    		
						    		stage.setScene(scene);
						    		stage.show();
						    		
						    		stage.setOnCloseRequest(e -> control.closeWindows());
						    		Stage mystage = (Stage) this.boton_volver.getScene().getWindow();
						    		mystage.close();
						    		
						    		 
						    	     
						    		}
						    		catch(Exception e) {
						    			e.printStackTrace();
						    		}
							}
							
							
						       
						rs.close();
						stmt.close();
						//System.out.println(Tipo);
						//return Tipo;
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Se ha producido un error ");
					}
						
						}
					} catch(Exception e){
							e.printStackTrace();
							System.out.println("Se ha producido un error ");
						}
	    	
	    }

	    @FXML
	    void listar_cuidadores(ActionEvent event) {
	    	Connection conn = null;
				Statement stmt = null;
				String sql;
				try {
					//STEP 1: Register JDBC driver
					Class.forName("org.mariadb.jdbc.Driver");
					//STEP 2: Open a connection
					try {
						conn = DriverManager.getConnection(
								"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
						System.out.println("Connectado a la Base de Datos...");

						//consulta
						sql = "SELECT * FROM cuidador";

						System.out.println("sql command: "+ sql);
						stmt = conn.createStatement();
						ResultSet rs = stmt.executeQuery( sql );
						System.out.println(rs);
						String nombrecui = null;
						String appellidocui = null;
						String dnicui=null;
						String nuevo[][] = new String[1][3];
						int largo[] = new int[3];
						int contador = 0;
						//int Tipo = 0;
						while( rs.next() ) {

							nombrecui = rs.getString("nombre");
							appellidocui = rs.getString("apellidos");
							dnicui = rs.getString("DNI");

							nuevo[0][0] = nombrecui;
							nuevo[0][1] = appellidocui;
							nuevo[0][2] = dnicui;
							
							if(contador == 0) {
								largo[0] = 20;
								largo[1] = nuevo[0][0].length() + 20;
								largo[2] = nuevo[0][1].length() + 20;
								
							}
							contador++;
							textarea_listar_cuidadores.appendText(String.format("%" + largo[0] + "s", nuevo[0][0]));
							textarea_listar_cuidadores.appendText(String.format("%" + largo[1] + "s", nuevo[0][1]));
							textarea_listar_cuidadores.appendText(String.format("%" + largo[2] + "s", nuevo[0][2]+"\n"));
							
						}       
						rs.close();
						stmt.close();
						//System.out.println(Tipo);
						//return Tipo;
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Se ha producido un error ");
					}    

					conn.close();
				} catch (SQLException se) {   
					se.printStackTrace();
				} catch (Exception e) {  
					e.printStackTrace();
				} finally {  
					try {
						if (stmt != null) {conn.close();}
					} catch (SQLException se) { }
					try {
						if (conn != null) {conn.close();}
					} catch (SQLException se) { se.printStackTrace();
					}
				}
				return;
	    }

	    @FXML
	    void listar_pacientes(ActionEvent event) {
	    	Connection conn = null;
			Statement stmt = null;
			String sql;
			try {
				//STEP 1: Register JDBC driver
				Class.forName("org.mariadb.jdbc.Driver");
				//STEP 2: Open a connection
				try {
					conn = DriverManager.getConnection(
							"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
					System.out.println("Connectado a la Base de Datos...");

					//consulta
					sql = "SELECT * FROM paciente ";

					System.out.println("sql command: "+ sql);
					stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery( sql );
					System.out.println(rs);
					String nombrepac = null;
					String appellidopac = null;
					String dnipac=null;
					String nuevo[][] = new String[1][3];
					int largo[] = new int[3];
					int contador = 0;
					//int Tipo = 0;
					while( rs.next() ) {

						nombrepac = rs.getString("nombre");
						appellidopac = rs.getString("apellidos");
						dnipac = rs.getString("DNI");

						nuevo[0][0] = nombrepac;
						nuevo[0][1] = appellidopac;
						nuevo[0][2] = dnipac;
						
						if(contador == 0) {
							largo[0] = 20;
							largo[1] = nuevo[0][0].length() + 20;
							largo[2] = nuevo[0][1].length() + 20;
							
						}
						contador++;
						textarea_listar_pacientes.appendText(String.format("%" + largo[0] + "s", nuevo[0][0]));
						textarea_listar_pacientes.appendText(String.format("%" + largo[1] + "s", nuevo[0][1]));
						textarea_listar_pacientes.appendText(String.format("%" + largo[2] + "s", nuevo[0][2]+"\n"));
						
					}       
					rs.close();
					stmt.close();
					//System.out.println(Tipo);
					//return Tipo;
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Se ha producido un error ");
				}    

				conn.close();
			} catch (SQLException se) {   
				se.printStackTrace();
			} catch (Exception e) {  
				e.printStackTrace();
			} finally {  
				try {
					if (stmt != null) {conn.close();}
				} catch (SQLException se) { }
				try {
					if (conn != null) {conn.close();}
				} catch (SQLException se) { se.printStackTrace();
				}
			}
			return;

	    }

	    
	    
	    @FXML
	    void volver(ActionEvent event) {
try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_medico_opcional.fxml"));
	    		
	    		MenuMedicoController2 control = new MenuMedicoController2();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		stage.setOnCloseRequest(e -> control.closeWindows());
	    		Stage mystage = (Stage) this.boton_volver.getScene().getWindow();
	    		mystage.close();
	    		
	    		 
	    	     
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
	    }

	    
	    
	    @FXML
	    void initialize() {
	        assert boton_listar_cuidadores != null : "fx:id=\"boton_listar_cuidadores\" was not injected: check your FXML file 'vista_asignacion.fxml'.";
	        assert textarea_listar_cuidadores != null : "fx:id=\"textarea_listar_cuidadores\" was not injected: check your FXML file 'vista_asignacion.fxml'.";
	        assert boton_listar_pacientes != null : "fx:id=\"boton_listar_pacientes\" was not injected: check your FXML file 'vista_asignacion.fxml'.";
	        assert textarea_listar_pacientes != null : "fx:id=\"textarea_listar_pacientes\" was not injected: check your FXML file 'vista_asignacion.fxml'.";
	        assert textfield_dni_cuidador != null : "fx:id=\"textfield_dni_cuidador\" was not injected: check your FXML file 'vista_asignacion.fxml'.";
	        assert textfield_dni_paciente != null : "fx:id=\"textfield_dni_paciente\" was not injected: check your FXML file 'vista_asignacion.fxml'.";
	        assert boton_asignar != null : "fx:id=\"boton_asignar\" was not injected: check your FXML file 'vista_asignacion.fxml'.";

	    }

		public Object closeWindows() {
			// TODO Auto-generated method stub
			return null;
		}
	}
