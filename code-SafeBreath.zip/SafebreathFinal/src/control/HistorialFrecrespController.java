package control;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.TextArea;

public class HistorialFrecrespController {
	
//  Database credentials
		static final String USER = "prb_SafeBreath";
		static final String PASS = "camaleon";

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea text_imprimir_frecResp;

    @FXML
    private LineChart<String, Double> graf_frecResp;

    @FXML
    void mostrar_frecResp(ActionEvent event) {
        Connection conn = null;
     	Statement stmt = null;
     	String sql;
     	try {
     		//STEP 1: Register JDBC driver
     		Class.forName("org.mariadb.jdbc.Driver");
     		//STEP 2: Open a connection
     		try {
     			conn = DriverManager.getConnection(
     					"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
     			System.out.println("Connectado a la Base de Datos...");

     			//consulta
     			sql = "SELECT * FROM FrecResp JOIN paciente USING (id_P) WHERE paciente.id_P= FrecResp.id_P AND 21=FrecResp.id_P";

     			System.out.println("sql command: "+ sql);
     			stmt = conn.createStatement();
     			ResultSet rs = stmt.executeQuery( sql );
     			System.out.println(rs);
     			int frecuResp = 0;
     			Timestamp timestamp = null;
     			String antiguo = null;
     			String nuevo = null;
     			
     			
     			
     			//int Tipo = 0;

     			while( rs.next() ) {

     				frecuResp = rs.getInt("frecuResp");
     				timestamp = rs.getTimestamp("tiempoRegistroF");

     				antiguo = nuevo;
     				nuevo = antiguo  + frecuResp +"\t" + "\t"+ timestamp +"\n" ;
     			}       
     			text_imprimir_frecResp.setText(nuevo);
     			rs.close();
     			stmt.close();
     			//System.out.println(Tipo);
     			//return Tipo;
     		}catch(Exception e){
     			e.printStackTrace();
     			System.out.println("Se ha producido un error ");
     		}    

     		conn.close();
     	} catch (SQLException se) {   
     		se.printStackTrace();
     	} catch (Exception e) {  
     		e.printStackTrace();
     	} finally {  
     		try {
     			if (stmt != null) {conn.close();}
     		} catch (SQLException se) { }
     		try {
     			if (conn != null) {conn.close();}
     		} catch (SQLException se) { se.printStackTrace();
     		}
     	}
     	return;
    }

private void graf_frecResp(double parametro, String nombre) {
      	
      	//grafica.getData().clear();
      	
      	Series<String,Double> series = new XYChart.Series<>();
      	series.setName(nombre);
      	
      	series.getData().add(new XYChart.Data<>(nombre,parametro));
      	graf_frecResp.getData().add(series);
      }
    
    @FXML
    void mostrar_frecResp2(ActionEvent event) {
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM FrecResp JOIN paciente USING (id_P) WHERE paciente.id_P= FrecResp.id_P AND 21=FrecResp.id_P";
						

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				int FrecuResp;
				Timestamp tiempo;

			

				while( rs.next() ) {

					FrecuResp = rs.getInt("FrecuResp");
					tiempo = rs.getTimestamp("tiempoRegistroF");
					System.out.println(FrecuResp);
					
					System.out.println(tiempo);
					graf_frecResp(FrecuResp,String.valueOf(tiempo));
					
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			
			
			}
		}

    }

    @FXML
    void initialize() {
        assert text_imprimir_frecResp != null : "fx:id=\"text_imprimir_frecResp\" was not injected: check your FXML file 'vista_historial_frecResp.fxml'.";
        assert graf_frecResp != null : "fx:id=\"graf_frecResp\" was not injected: check your FXML file 'vista_historial_frecResp.fxml'.";

    }
}
