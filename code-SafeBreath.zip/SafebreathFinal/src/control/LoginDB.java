package control;

import java.awt.Button;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Db;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class LoginDB {
	
	 //  Database credentials
	  static final String USER = "prb_SafeBreath";
	  static final String PASS = "camaleon";

	public static String nombre;
	  
	public static String usuario;
	  
    public static int id;
    
    public static String[] usuarioN = new String[5];
    
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField usuarioS;

    @FXML
    private PasswordField contrasenaS;
    
    @FXML
    private Button boton_login;

    @FXML
    void iniciarSesion(ActionEvent event) {
    	ResultSet rs;
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				
    	usuario= usuarioS.getText();       //estos van a ser los q escribe el usuario
    	String contrasena = contrasenaS.getText();
    	
    	int tipo = Db.login(usuario, contrasena);

		if (tipo == 0) {
			//mandar error de usuario
try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_error_login.fxml"));
	    		
	    		ErrorLogin control = new ErrorLogin();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
	    		Stage stage2 = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
	    		stage2.close();
	    		
	    		 
	    	     
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
		}
		if (tipo == 1) {
			
			nombre = Db.nombre(usuario, tipo);

			sql = "SELECT * FROM paciente WHERE paciente.usuario = \""+ usuario + "\" AND paciente.contrasena = \"" +contrasena+"\"";

			stmt = conn.createStatement();
			rs = stmt.executeQuery( sql );

			while ( rs.next() ) {
				id = rs.getInt("id_P");  //se coge el tipo de usuario para saber q menu abrir
			}

			//abrir menu de paciente
try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_paciente.fxml"));
	    		
	    		MenuPacienteController control = new MenuPacienteController();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
	    		Stage stage2 = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
	    		stage2.close();
	    		
	    		
	    	
	    	     
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
			
		} 
		if (tipo == 2) {

			nombre = Db.nombre(usuario, tipo);
			
			sql = "SELECT * FROM medico WHERE medico.usuario = \""+ usuario + "\" AND medico.contrasena = \"" +contrasena+"\"";

			stmt = conn.createStatement();
			rs = stmt.executeQuery( sql );

			while ( rs.next() ) {
				id = rs.getInt("id_M");  //se coge el tipo de usuario para saber q menu abrir
			}

			//abrir menu de medico
try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_medico_opcional.fxml"));
	    		
	    		MenuMedicoController2 control = new MenuMedicoController2();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
	    		Stage stage2 = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
	    		stage2.close();
	    		
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
		}
		if (tipo == 3) {

			nombre = Db.nombre(usuario, tipo);
			
		sql = "SELECT * FROM cuidador WHERE cuidador.usuario = \""+ usuario + "\" AND cuidador.contrasena = \"" +contrasena+"\"";

			stmt = conn.createStatement();
			rs = stmt.executeQuery( sql );

			while ( rs.next() ) {
				id = rs.getInt("id_C");  //se coge el tipo de usuario para saber q menu abrir
			}

			//abrir menu de cuidador
try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_cuidador.fxml"));
	    		
	    		MenuCuidadorController control = new MenuCuidadorController();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
	    		Stage stage2 = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
	    		stage2.close();
	    		
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
			
		}
			
    }catch(Exception e){
		e.printStackTrace();}
		}catch(Exception e){
			e.printStackTrace();}
    }

    @FXML
    void initialize() {
        assert usuarioS != null : "fx:id=\"usuarioS\" was not injected: check your FXML file 'vista_login.fxml'.";
        assert contrasenaS != null : "fx:id=\"contrasenaS\" was not injected: check your FXML file 'vista_login.fxml'.";

    }

	public Object closeWindows() {
		// TODO Auto-generated method stub
		return null;
	}
}

