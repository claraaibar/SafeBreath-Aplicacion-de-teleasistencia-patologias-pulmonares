package control;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.time.LocalDate;
import java.util.Vector;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.sun.javafx.scene.control.skin.FXVK.Type;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.stage.Stage;
import model.Db;
import model.Paciente;


import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;


	

	public class MenuMedicoController2 {
	

		//  Database credentials
		static final String USER = "prb_SafeBreath";
		static final String PASS = "camaleon";

	    @FXML
	    private TextField MdniPaciente2;

	    @FXML
	    private TextArea Mlistarpacientes2;

	    @FXML
	    private Button boton_cerrar_sesion2;

	    @FXML
	    private Button boton_registrar_cuidador2;

	    @FXML
	    private Button boton_registrar_paciente2;

	    @FXML
	    private TextField etiquetaNombreMedico;

	    @FXML
	    private TextField fCardiaca;

	    @FXML
	    private TextField fRespiratoria;

	    @FXML
	    private Button mostrarFreccard2;
	    @FXML
	    private Button b_buscar_paciente;
	    @FXML
	    private Button mostrarFrespiratoria2;

	    @FXML
	    private Button mostrarOxSangre2;

	    @FXML
	    private Button mostrarTemperatura2;

	    @FXML
	    private TextField presionsanguinea;
	    
	    @FXML
	    private Button boton_asignar;

	    @FXML
	    private TextField temperatura;
	    
	    public static int buscar = 0;
	    
	    

	    @FXML
	    void buscarPaciente2(ActionEvent event) {
	    	
	    	String dni = MdniPaciente2.getText();
	    	
	    	int idP = Db.buscarM(dni, LoginDB.id);
	    	
	    	if (idP == 0) {
	    		buscar = 1;
	    		try {
	        		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_error_registro.fxml"));
	           		
	           		ErrorRegistro control = new ErrorRegistro();
	           		
	           		loader2.setController(control);

	           		Parent root = loader2.load();
	           		
	           		Scene scene = new Scene(root);
	           		Stage stage = new Stage();
	           	
	           		stage.setScene(scene);
	           		stage.show();
	           		
	           		Stage stage2 = (Stage) this.b_buscar_paciente.getScene().getWindow();
		   	        stage2.close();
	        		
	           		}
	           		catch(Exception e) {
	           			e.printStackTrace();
	           		}
	    	} else {
	    		buscar = 0;
	    		
	    		LoginDB.usuarioN = Db.usuario(dni);
	    		
	    		try {
		    		
		    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_medico.fxml"));
		    		
		    		MenuMedicoController control = new MenuMedicoController();
		    		
		    		loader2.setController(control);

		    		Parent root = loader2.load();
		    		
		    		Scene scene = new Scene(root);
		    		Stage stage = new Stage();
		    		
		    		stage.setScene(scene);
		    		stage.show();
		    		
		    		 
		    	     
		    		}
		    		catch(Exception e) {
		    			e.printStackTrace();
		    		}
	    	}
	    }

	    
	    @FXML
	    void asignarCuidador(ActionEvent event) {
try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_asignacion.fxml"));
	    		
	    		AsignacionController control = new AsignacionController();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		stage.setOnCloseRequest(e -> control.closeWindows());
	    		Stage mystage = (Stage) this.boton_asignar.getScene().getWindow();
	    		mystage.close();
	    		
	    		 
	    	     
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
	    }
	    
	    @FXML
	    void cerrarsesion2(ActionEvent event) {
			try {
				//    		
				FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_principal.fxml"));

				MenuPrincipalControllerDB control = new MenuPrincipalControllerDB();

				loader2.setController(control);

				Parent root = loader2.load();

				Scene scene = new Scene(root);
				Stage stage = new Stage();

				stage.setScene(scene);
				stage.show();
				
				Stage stage2 = (Stage) this.etiquetaNombreMedico.getScene().getWindow();
	   	        stage2.close();
	   		


			}
			catch(Exception e) {
				e.printStackTrace();
			}	
		}


	   

	    @FXML
	    void mostrarPacientes2(ActionEvent event) {
	    	Connection conn = null;
			Statement stmt = null;
			String sql;
			try {
				//STEP 1: Register JDBC driver
				Class.forName("org.mariadb.jdbc.Driver");
				//STEP 2: Open a connection
				try {
					conn = DriverManager.getConnection(
							"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
					System.out.println("Connectado a la Base de Datos...");

					//consulta
					sql = "SELECT * FROM paciente WHERE paciente.id_M = \""+ LoginDB.id + "\"";

					System.out.println("sql command: "+ sql);
					stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery( sql );
					System.out.println(rs);
					String nombrepac = null;
					String appellidopac = null;
					String dnipac=null;
					String nuevo[][] = new String[1][3];
					int largo[] = new int[3];
					int contador = 0;
					//int Tipo = 0;
					while( rs.next() ) {

						nombrepac = rs.getString("nombre");
						appellidopac = rs.getString("apellidos");
						dnipac = rs.getString("DNI");

						nuevo[0][0] = nombrepac;
						nuevo[0][1] = appellidopac;
						nuevo[0][2] = dnipac;
						
						if(contador == 0) {
							largo[0] = 20;
							largo[1] = nuevo[0][0].length() + 45;
							largo[2] = nuevo[0][1].length() + 30;
							
						}
						contador++;
						Mlistarpacientes2.appendText(String.format("%" + largo[0] + "s", nuevo[0][0]));
						Mlistarpacientes2.appendText(String.format("%" + largo[1] + "s", nuevo[0][1]));
						Mlistarpacientes2.appendText(String.format("%" + largo[2] + "s", nuevo[0][2]+"\n"));
						
					}       
					rs.close();
					stmt.close();
					//System.out.println(Tipo);
					//return Tipo;
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Se ha producido un error ");
				}    

				conn.close();
			} catch (SQLException se) {   
				se.printStackTrace();
			} catch (Exception e) {  
				e.printStackTrace();
			} finally {  
				try {
					if (stmt != null) {conn.close();}
				} catch (SQLException se) { }
				try {
					if (conn != null) {conn.close();}
				} catch (SQLException se) { se.printStackTrace();
				}
			}
			return;


	    }
	    
	    @FXML
	    void mostrarFrecCard2 (ActionEvent event){
try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_error_historial.fxml"));
	    		
	    		ErrorHistorialController control = new ErrorHistorialController();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		stage.setOnCloseRequest(e -> control.closeWindows());
	    		Stage mystage = (Stage) this.mostrarFreccard2.getScene().getWindow();
	    		mystage.close();
	    		
	    		 
	    	     
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
	    	
	    	
	    }

	    @FXML
	    void mostrarOxSangre (ActionEvent event){
try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_error_historial.fxml"));
	    		
	    		ErrorHistorialController control = new ErrorHistorialController();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		stage.setOnCloseRequest(e -> control.closeWindows());
	    		Stage mystage = (Stage) this.mostrarOxSangre2.getScene().getWindow();
	    		mystage.close();
	    		
	    		 
	    	     
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
	    	
	    	
	    }
	    
	    @FXML
	    void mostrarFrecResp (ActionEvent event){
try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_error_historial.fxml"));
	    		
	    		ErrorHistorialController control = new ErrorHistorialController();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		stage.setOnCloseRequest(e -> control.closeWindows());
	    		Stage mystage = (Stage) this.mostrarFrespiratoria2.getScene().getWindow();
	    		mystage.close();
	    		
	    		 
	    	     
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
	    	
	    	
	    }
	    
	    
	    @FXML
	    void mostrar_historial_temperatura (ActionEvent event){
	    	try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_error_historial.fxml"));
	    		
	    		ErrorHistorialController control = new ErrorHistorialController();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		stage.setOnCloseRequest(e -> control.closeWindows());
	    		Stage mystage = (Stage) this.mostrarTemperatura2.getScene().getWindow();
	    		mystage.close();
	    		
	    		 
	    	     
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
	    	
	    	
	    }

	    
	    
	    
	    
	    
	    
	    
	    @FXML
	    void registrarCuidador(ActionEvent event) {

			try {
				//    		
				FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_registro_cuidador.fxml"));

				RegistroCuidadorControllerDB control = new RegistroCuidadorControllerDB();

				loader2.setController(control);

				Parent root = loader2.load();

				Scene scene = new Scene(root);
				Stage stage = new Stage();

				stage.setScene(scene);
				stage.show();
				
				Stage stage2 = (Stage) this.etiquetaNombreMedico.getScene().getWindow();
	   	        stage2.close();


			}
			catch(Exception e) {
				e.printStackTrace();
			}	
		}

	    @FXML
	    void registrarPacientes(ActionEvent event) {

			try {
				//    		
				FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_registro_paciente.fxml"));

				RegistroPacienteControllerDB control = new RegistroPacienteControllerDB();

				loader2.setController(control);

				Parent root = loader2.load();

				Scene scene = new Scene(root);
				Stage stage = new Stage();

				stage.setScene(scene);
				stage.show();
				
				Stage stage2 = (Stage) this.etiquetaNombreMedico.getScene().getWindow();
	   	        stage2.close();


			}
			catch(Exception e) {
				e.printStackTrace();
			}	
		}
	    @FXML
	    void initialize() {
	    	etiquetaNombreMedico.setText(LoginDB.nombre);
	        assert etiquetaNombreMedico != null : "fx:id=\"etiquetaNombreMedico\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert boton_cerrar_sesion2 != null : "fx:id=\"boton_cerrar_sesion2\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert presionsanguinea != null : "fx:id=\"presionsanguinea\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert fCardiaca != null : "fx:id=\"fCardiaca\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert fRespiratoria != null : "fx:id=\"fRespiratoria\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert temperatura != null : "fx:id=\"temperatura\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert mostrarOxSangre2 != null : "fx:id=\"mostrarOxSangre2\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert mostrarFreccard2 != null : "fx:id=\"mostrarFreccard2\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert mostrarFrespiratoria2 != null : "fx:id=\"mostrarFrespiratoria2\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert mostrarTemperatura2 != null : "fx:id=\"mostrarTemperatura2\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert boton_registrar_paciente2 != null : "fx:id=\"boton_registrar_paciente2\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert boton_registrar_cuidador2 != null : "fx:id=\"boton_registrar_cuidador2\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert MdniPaciente2 != null : "fx:id=\"MdniPaciente2\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";
	        assert Mlistarpacientes2 != null : "fx:id=\"Mlistarpacientes2\" was not injected: check your FXML file 'vista_menu_medico_opcional.fxml'.";

	    }

		public Object closeWindows() {
			// TODO Auto-generated method stub
			return null;
		}
	}

	
	