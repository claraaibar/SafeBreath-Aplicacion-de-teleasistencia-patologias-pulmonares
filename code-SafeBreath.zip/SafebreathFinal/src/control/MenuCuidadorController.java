package control;

import java.awt.Label;
import java.io.FileReader;

import java.io.IOException;
import java.io.Reader;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.Vector;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import model.Db;
import model.Paciente;
import model.Sensor;
import javafx.scene.control.TextArea;


import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

public class MenuCuidadorController {
	  //  Database credentials
	  static final String USER = "prb_SafeBreath";
	  static final String PASS = "camaleon";

    @FXML
    private TextField nombreCuidador;

    @FXML
    private Text presionSanguinea;

    @FXML
    private Text fcardiaca;

    @FXML
    private TextField frespiratoria;

    @FXML
    private TextField temperatura;

    @FXML
    private TextField MdniPaciente;

    @FXML
    private TextArea Mlistarpacientes;
    

    @FXML
    private TextArea MlistarUnPaciente;
    
    @FXML
    private Button boton_cerrar_sesion;

    public static int buscar = 0;
    
    public static String[] usuario = new String[5];
    
    @FXML
    void buscarPaciente(ActionEvent event) {
    	String dni = MdniPaciente.getText();
    	
    	int idP = Db.buscarC(dni, LoginDB.id);
    	
    	if (idP == 0) {
    		buscar = 1;
    		try {
        		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_error_registro.fxml"));
           		
           		ErrorRegistro control = new ErrorRegistro();
           		
           		loader2.setController(control);

           		Parent root = loader2.load();
           		
           		Scene scene = new Scene(root);
           		Stage stage = new Stage();
           	
           		stage.setScene(scene);
           		stage.show();
           		
           		Stage stage2 = (Stage) this.Mlistarpacientes.getScene().getWindow();
	   	        stage2.close();
        		
           		}
           		catch(Exception e) {
           			e.printStackTrace();
           		}
    	} else {
    		buscar = 0;
    		
    		LoginDB.usuarioN = Db.usuario(dni);
    		
    		try {
	    		
	    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_medico.fxml"));
	    		
	    		MenuMedicoController control = new MenuMedicoController();
	    		
	    		loader2.setController(control);

	    		Parent root = loader2.load();
	    		
	    		Scene scene = new Scene(root);
	    		Stage stage = new Stage();
	    		
	    		stage.setScene(scene);
	    		stage.show();
	    		
	    		 
	    	     
	    		}
	    		catch(Exception e) {
	    			e.printStackTrace();
	    		}
    	}

    }

    @FXML
    void cerrarsesion(ActionEvent event) {

     	try { 		
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_principal.fxml"));
    		
    		MenuPrincipalControllerDB control = new MenuPrincipalControllerDB();
    		
    		loader2.setController(control);

    		Parent root = loader2.load();
    		
    		Scene scene = new Scene(root);
    		Stage stage = new Stage();
    		
    		stage.setScene(scene);
    		stage.show();
    		
    		Stage stage2 = (Stage) this.boton_cerrar_sesion.getScene().getWindow();
   	        stage2.close();
    		
    		
    		}
    		catch(Exception e) {
    			e.printStackTrace();
    		}	
    }

    @FXML
    void mostrarPacientes(ActionEvent event) {
    	
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT id_P FROM Supervisa WHERE Supervisa.id_C='"+LoginDB.id+"'";

				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String idP = null;


				while( rs.next() ) {

					idP = rs.getString("id_P");
					
					try {
						
						conn = DriverManager.getConnection(
								"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
						//consulta
						sql = "SELECT nombre, apellidos, DNI FROM paciente WHERE paciente.id_P = '"+ idP + "'";

						stmt = conn.createStatement();
						ResultSet rs2 = stmt.executeQuery( sql );
						String nombrecui = null;
						String apellidocui = null;
						String dni = null;


						while( rs2.next() ) {

							nombrecui = rs2.getString("nombre");
							apellidocui = rs2.getString("apellidos");
							dni = rs2.getString("DNI");
							Mlistarpacientes.appendText(nombrecui+ " " + apellidocui+ "  DNI= "+ dni + "\n");
						}       
						
						rs2.close();
						stmt.close();
						//System.out.println(Tipo);
						
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Se ha producido un error ");
					}
					
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				
				
				
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}     

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
    }
    
    
    
    
    @FXML
    void mostrarFcardiaca(ActionEvent event) {

    }

    @FXML
    void mostrarFrespiratoria(ActionEvent event) {

    }

   

    @FXML
    void mostrarPresionSanguinea(ActionEvent event) {

    }

    @FXML
    void mostrarTemperatura(ActionEvent event) {

    }
    
    @FXML
    void initialize() {
        nombreCuidador.setText(LoginDB.nombre);
    }

    
    public static String dniP = null; //Este parametro y todo lo de debajo va en el controlador de 
     								  //la ventana nueva solo para asignar
    
    public static String dniC = null; //Este parametro hace falta si asigna el medico
    
    void botonMostrarP() {			//Esto es para mostrar todos los pacientes y que de esa manera 
    							    //se pueda coger el dni (si quereis q lo haga el medico teneis q 
    							    //copiar esta misma pero aparte hacer otra para q se impriman los cuidadores)
    	
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT nombre, apellidos, dni FROM paciente";

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String nombrepac = null;
				String appellidopac = null;
				String dnipac=null;
				while( rs.next() ) {

					nombrepac = rs.getString("nombre");
					appellidopac = rs.getString("apellidos");
					dnipac = rs.getString("DNI");

					Mlistarpacientes.appendText(nombrepac+ " "+appellidopac+", DNI: "+dnipac+"\n");
					
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				//return Tipo;
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
    	
    }
    
    void botonAsignarCuidador() {			//hacen falta 1 textfield para poner el dni del paciente
    										//que quieres asignar (2 si quereis q lo haga el medico 
    										//para coger el dni del cuidador tambn)
    	
    	
    /*										  Esto es el codigo si decidis q lo haga el medico, si lo 
      										  hace el cuidador esta debajo
     
    	
    	dniP = NOMBREDELTEXFIELD.getText();
    	
    	dniC = NOMBREDELTEXFIELD.getText();
    	
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

				//consulta
				sql = "SELECT id_P FROM paciente WHERE paciente.id_P = \""+ dniP + "\"";

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String idP = null;
				while( rs.next() ) {

					idP = rs.getString("id_P");
				}
				if(idP != null) {
					
					try {
						
						Class.forName("org.mariadb.jdbc.Driver");
						conn = DriverManager.getConnection(
								"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

						//consulta
						sql = "SELECT id_C FROM paciente WHERE cuidador.id_C = \""+ dniC + "\"";

						System.out.println("sql command: "+ sql);
						stmt = conn.createStatement();
						rs = stmt.executeQuery( sql );
						System.out.println(rs);
						String idC = null;
						while( rs.next() ) {

							idC = rs.getString("id_C");
						}
						if (idC != null) {
							
							try {
								Class.forName("org.mariadb.jdbc.Driver");
								conn = DriverManager.getConnection("jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
								System.out.println("Connectado a la Base de Datos...");
								

								sql = "Insert into Supervisa(id_P, id_C) values('"+idP+"','"+idC+"');"; //el first es del valor de la tabla first name"
								System.out.println("sql Insert: "+sql);
								stmt = conn.createStatement(); 
								stmt.executeUpdate(sql);  
								stmt.close();
								
							} catch (SQLException se) {
								//Handle errors for JDBC
								se.printStackTrace();
							} catch (Exception e) {
								//Handle errors for Class.forName
								e.printStackTrace();
							}
							
						}
						
						
					       
					rs.close();
					stmt.close();
					//System.out.println(Tipo);
					//return Tipo;
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Se ha producido un error ");
				}
					}
				} catch(Exception e){
						e.printStackTrace();
						System.out.println("Se ha producido un error ");
					}
					
				*/
				
												//Este es el codigo si lo hace el cuidador
    	//dniP = NOMBREDELTEXFIELD.getText();
    	
//    	Connection conn = null;
//		Statement stmt = null;
//		String sql;
//		try {
//			//STEP 1: Register JDBC driver
//			Class.forName("org.mariadb.jdbc.Driver");
//				conn = DriverManager.getConnection(
//						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
//
//				//consulta
//				sql = "SELECT id_P FROM paciente WHERE paciente.id_P = \""+ dniP + "\"";
//
//				System.out.println("sql command: "+ sql);
//				stmt = conn.createStatement();
//				ResultSet rs = stmt.executeQuery( sql );
//				System.out.println(rs);
//				String idP = null;
//				while( rs.next() ) {
//
//					idP = rs.getString("id_P");
//				}
//				if (idP != null) {
//					
//					try {
//						Class.forName("org.mariadb.jdbc.Driver");
//						conn = DriverManager.getConnection("jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
//						System.out.println("Connectado a la Base de Datos...");
//						
//
//						sql = "Insert into Supervisa(id_P, id_C) values('"+idP+"','"+LoginDB.id+"');"; //el first es del valor de la tabla first name"
//						System.out.println("sql Insert: "+sql);
//						stmt = conn.createStatement(); 
//						stmt.executeUpdate(sql);  
//						stmt.close();
//						
//					} catch (SQLException se) {
//						//Handle errors for JDBC
//						se.printStackTrace();
//					} catch (Exception e) {
//						//Handle errors for Class.forName
//						e.printStackTrace();
//					}	
//					
//				}
//					
//					
//				       
//				rs.close();
//				stmt.close();
//				//System.out.println(Tipo);
//				//return Tipo;
//			}catch(Exception e){
//				e.printStackTrace();
//				System.out.println("Se ha producido un error ");
//			}
    }
}

