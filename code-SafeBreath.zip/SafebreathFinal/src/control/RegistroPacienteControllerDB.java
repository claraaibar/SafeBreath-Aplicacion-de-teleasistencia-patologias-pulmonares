package control;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Db;

public class RegistroPacienteControllerDB {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button boton_registro_paciente;

    @FXML
    private ChoiceBox<String> choice_genero_paciente;
    @FXML
    private DatePicker date_fn_paciente;

    @FXML
    private TextField text_apellidos_paciente;
    @FXML
    private TextField t_dni_Cuidador;

    @FXML
    private TextField text_contrasena_paciente;

    @FXML
    private TextField text_nombre_paciente;

    @FXML
    private TextField text_tlf_paciente;

    @FXML
    private TextField text_usuario_paciente;

    @FXML
    private TextField text_DNI_paciente;
    
    @FXML
    private Button boton_cancelar;
    
    @FXML
    void registrar_paciente(ActionEvent event) {
    	
    	String nombre = text_nombre_paciente.getText();;
    	String apellidos = text_apellidos_paciente.getText();
    	String DNI = text_DNI_paciente.getText();
    	String usuario = text_usuario_paciente.getText();
    	String contrasena = text_contrasena_paciente.getText();
    	String genero = choice_genero_paciente.getValue();
    	String tlf = text_tlf_paciente.getText();
    	String cuidador_asociado = t_dni_Cuidador.getText();
    	int validado = 0;
    	int idm = LoginDB.id;
    	
    	int telefono = 0;
    	if (tlf.equals("")) {
    	} else {
    		for (int i = 0; i < tlf.length(); i++) { 
    			if (Character.isDigit(tlf.charAt(i))){
    		telefono = Integer.parseInt(tlf);
    		}
    	}
    		
    	}
    	LocalDate fn = date_fn_paciente.getValue();
    	String fechan = null;
    	
    	if (tlf.equals("")) {
    	} else {
    		fechan = fn.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    	}
    	validado = Db.crearPacientes(nombre, apellidos, DNI, usuario, contrasena, fechan, genero, telefono, idm);
    	Db.asignar_cuidador(DNI, cuidador_asociado);
    	System.out.println(cuidador_asociado);
    	if (validado == 1) {
    		
    		try {
         		 
           		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_principal.fxml"));
           		
           		MenuPrincipalControllerDB control = new MenuPrincipalControllerDB();
           		
           		loader2.setController(control);

           		Parent root = loader2.load();
           		
           		Scene scene = new Scene(root);
           		Stage stage = new Stage();
           		
           		stage.setScene(scene);
           		stage.show();
           		
           		Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
	    		Stage stage2 = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
	    		stage2.close();
        		
           		}
           		catch(Exception e) {
           			e.printStackTrace();
           		}
    	} else {
    		
    		try {
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_error_registro.fxml"));
       		
       		ErrorRegistro control = new ErrorRegistro();
       		
       		loader2.setController(control);

       		Parent root = loader2.load();
       		
       		Scene scene = new Scene(root);
       		Stage stage = new Stage();
       		
       		stage.setScene(scene);
       		stage.show();
       		
       		Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
    		Stage stage2 = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
    		stage2.close();
    		
       		}
       		catch(Exception e) {
       			e.printStackTrace();
       		}
    	}

    }


    
    @FXML
    void cancelar(ActionEvent event) {
    	try {
			//    		
			FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_medico_opcional.fxml"));

			MenuMedicoController2 control = new MenuMedicoController2();

			loader2.setController(control);

			Parent root = loader2.load();

			Scene scene = new Scene(root);
			Stage stage = new Stage();

			stage.setScene(scene);
			stage.show();
			
			Stage stage2 = (Stage) this.boton_cancelar.getScene().getWindow();
   	        stage2.close();
   		


		}
		catch(Exception e) {
			e.printStackTrace();
		}	
    }
    
    @FXML
    void initialize() {
        
        
        ObservableList<String> genero = FXCollections.observableArrayList("masculino","femenino");
        choice_genero_paciente.setItems(genero);
    }

}
