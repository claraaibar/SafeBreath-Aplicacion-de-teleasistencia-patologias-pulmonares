package control;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ErrorHistorialController {

    @FXML
    private Button volverRegistro;

    @FXML
    void volver_menu_medico(ActionEvent event) {
    	try {
   		 
       		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_medico_opcional.fxml"));
       		
       		MenuMedicoController2 control = new MenuMedicoController2();
       		
       		loader2.setController(control);

       		Parent root = loader2.load();
       		
       		Scene scene = new Scene(root);
       		Stage stage = new Stage();
       		
       		stage.setScene(scene);
       		stage.show();
       		
       		stage.setOnCloseRequest(e -> control.closeWindows());
    		Stage mystage = (Stage) this.volverRegistro.getScene().getWindow();
    		mystage.close();
    		
       		}
       		catch(Exception e) {
       			e.printStackTrace();
       		}
    }

	public Object closeWindows() {
		// TODO Auto-generated method stub
		return null;
	}

}

