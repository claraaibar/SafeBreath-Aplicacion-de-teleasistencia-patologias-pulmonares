package control;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import model.Db;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class ErrorRegistro {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button volverRegistro;

    @FXML
    void iniciarSesionMedico(ActionEvent event) {
    	
    if (MenuMedicoController2.buscar == 1) {
    	try {
    		
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_medico_opcional.fxml"));
    		
    		MenuMedicoController2 control = new MenuMedicoController2();
    		
    		loader2.setController(control);

    		Parent root = loader2.load();
    		
    		Scene scene = new Scene(root);
    		Stage stage = new Stage();
    		
    		stage.setScene(scene);
    		stage.show();
    		
    		Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
    		Stage stage2 = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
    		stage2.close();
    		
    		}
    		catch(Exception e) {
    			e.printStackTrace();
    		}
    } else if (Db.tipoM == 1) {
    		try {
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_registro_paciente.fxml"));

			RegistroPacienteControllerDB control = new RegistroPacienteControllerDB();

			loader2.setController(control);

			Parent root = loader2.load();

			Scene scene = new Scene(root);
			Stage stage = new Stage();

			stage.setScene(scene);
			stage.show();
			
			Stage stage2 = (Stage) this.volverRegistro.getScene().getWindow();
   	        stage2.close();


		}
		catch(Exception e) {
			e.printStackTrace();
		}
    		
    	} else if (Db.tipoM == 2) {
    		
    		try {
    	   		 
           		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_registro_medico.fxml"));
           		
           		RegistroMedicoControllerDB control = new RegistroMedicoControllerDB();
           		
           		loader2.setController(control);

           		Parent root = loader2.load();
           		
           		Scene scene = new Scene(root);
           		Stage stage = new Stage();
           		
           		stage.setScene(scene);
           		stage.show();
           		
           		stage.setOnCloseRequest(e -> control.closeWindows());
        		Stage mystage = (Stage) this.volverRegistro.getScene().getWindow();
        		mystage.close();
        		
           		}
           		catch(Exception e) {
           			e.printStackTrace();
           		}
    		
    	} else if (Db.tipoM == 3) {
    		
    	   		 
    			try {
    				//    		
    				FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_registro_cuidador.fxml"));

    				RegistroCuidadorControllerDB control = new RegistroCuidadorControllerDB();

    				loader2.setController(control);

    				Parent root = loader2.load();

    				Scene scene = new Scene(root);
    				Stage stage = new Stage();

    				stage.setScene(scene);
    				stage.show();
    				
    				Stage stage2 = (Stage) this.volverRegistro.getScene().getWindow();
    	   	        stage2.close();


    			}
    			catch(Exception e) {
    				e.printStackTrace();
    			}	
    	
    	
    }
    }

    @FXML
    void initialize() {
        assert volverRegistro != null : "fx:id=\"volverRegistro\" was not injected: check your FXML file 'vista_error_registro.fxml'.";

    }
}

