package control;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.TextArea;

public class HistorialOxsangreController {

//  Database credentials
		static final String USER = "prb_SafeBreath";
		static final String PASS = "camaleon";
		
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea text_imprimir_oxSangre;

    @FXML
    private LineChart<String, Double> graf_oxSangre;

    @FXML
    void mostrar_oxSangre(ActionEvent event) {
        Connection conn = null;
    	Statement stmt = null;
    	String sql;
    	try {
    		//STEP 1: Register JDBC driver
    		Class.forName("org.mariadb.jdbc.Driver");
    		//STEP 2: Open a connection
    		try {
    			conn = DriverManager.getConnection(
    					"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
    			System.out.println("Connectado a la Base de Datos...");

    			//consulta
    			sql = "SELECT * FROM pulsioximetro JOIN paciente USING (id_P) WHERE paciente.id_P= pulsioximetro.id_P AND 21=pulsioximetro.id_P";

    			System.out.println("sql command: "+ sql);
    			stmt = conn.createStatement();
    			ResultSet rs = stmt.executeQuery( sql );
    			System.out.println(rs);
    			int oxSangre = 0;
    			Timestamp timestamp = null;
    			String antiguo = null;
    			String nuevo = null;
    			
    			
    			
    			//int Tipo = 0;

    			while( rs.next() ) {

    				oxSangre = rs.getInt("oxSangre");
    				timestamp = rs.getTimestamp("tiempoRegistroP");

    				antiguo = nuevo;
    				nuevo = antiguo  + oxSangre +"\t" + "\t"+ timestamp +"\n" ;
    			}       
    			text_imprimir_oxSangre.setText(nuevo);
    			rs.close();
    			stmt.close();
    			//System.out.println(Tipo);
    			//return Tipo;
    		}catch(Exception e){
    			e.printStackTrace();
    			System.out.println("Se ha producido un error ");
    		}    

    		conn.close();
    	} catch (SQLException se) {   
    		se.printStackTrace();
    	} catch (Exception e) {  
    		e.printStackTrace();
    	} finally {  
    		try {
    			if (stmt != null) {conn.close();}
    		} catch (SQLException se) { }
    		try {
    			if (conn != null) {conn.close();}
    		} catch (SQLException se) { se.printStackTrace();
    		}
    	}
    	return;
    }

  private void graf_oxSangre(double parametro, String nombre) {
      	
      	//grafica.getData().clear();
      	
      	Series<String,Double> series = new XYChart.Series<>();
      	series.setName(nombre);
      	
      	series.getData().add(new XYChart.Data<>(nombre,parametro));
      	graf_oxSangre.getData().add(series);
      }
    @FXML
    void mostrar_oxSangre2(ActionEvent event) {
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM pulsioximetro JOIN paciente USING (id_P) WHERE paciente.id_P= pulsioximetro.id_P AND 21=pulsioximetro.id_P";
						

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				int oxSangre;
				Timestamp tiempo;

			

				while( rs.next() ) {

					oxSangre = rs.getInt("oxSangre");
					tiempo = rs.getTimestamp("tiempoRegistroP");
					System.out.println(oxSangre);
					
					System.out.println(tiempo);
					graf_oxSangre(oxSangre,String.valueOf(tiempo));
					
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			
			
			}
		}
    }

    @FXML
    void initialize() {
        assert text_imprimir_oxSangre != null : "fx:id=\"text_imprimir_oxSangre\" was not injected: check your FXML file 'vista_historial_oxSangre.fxml'.";
        assert graf_oxSangre != null : "fx:id=\"graf_oxSangre\" was not injected: check your FXML file 'vista_historial_oxSangre.fxml'.";

    }
}
