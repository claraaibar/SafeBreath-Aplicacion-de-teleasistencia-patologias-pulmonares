package control;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.Vector;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Cuidador;
import model.Medico;
import model.Paciente;
import model.Sensor;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

public class MenuPacienteController {
	  //  Database credentials
	  static final String USER = "prb_SafeBreath";
	  static final String PASS = "camaleon";
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea etiquetadatospaciente;

    @FXML
    private TextField etiquetaNombrePaciente;

    @FXML
    private TextField misSensores;

    @FXML
    private Label sensores;

    @FXML
    private Button botonSensores;

    @FXML
    private TextArea misMedicos;

    @FXML
    private Button botonmedico;

    @FXML
    private Button botoncuidadores;

    @FXML
    private TextArea misCuidadores;

    @FXML
    private Button boton_cerrar_sesion;
  
    
    
    @FXML
    void MostrarMedicos(ActionEvent event) {
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT id_M FROM paciente WHERE paciente.id_P = '"+ LoginDB.id + "'";

				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String idM = null;


				while( rs.next() ) {

					idM = rs.getString("id_M");
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				
				try {
					
					conn = DriverManager.getConnection(
							"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
					//consulta
					sql = "SELECT nombre, apellidos FROM medico WHERE medico.id_M = '"+ idM + "'";

					stmt = conn.createStatement();
					rs = stmt.executeQuery( sql );
					System.out.println(rs);
					String nombremed = null;
					String apellidomed = null;


					while( rs.next() ) {

						nombremed = rs.getString("nombre");
						apellidomed = rs.getString("apellidos");
					}       
					misMedicos.setText(nombremed+ " " + apellidomed);
					rs.close();
					stmt.close();
					//System.out.println(Tipo);
					
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Se ha producido un error ");
				}
				
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}

    }

    	
    
    @FXML
    void MostrarCuidadores(ActionEvent event) {
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT id_C FROM Supervisa WHERE Supervisa.id_P='"+LoginDB.id+"'";

				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				String idC = null;


				while( rs.next() ) {

					idC = rs.getString("id_C");
					
					try {
						
						conn = DriverManager.getConnection(
								"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
						//consulta
						sql = "SELECT nombre, apellidos FROM cuidador WHERE cuidador.id_C = '"+ idC + "'";

						stmt = conn.createStatement();
						ResultSet rs2 = stmt.executeQuery( sql );
						String nombrecui = null;
						String apellidocui = null;
						String nuevo[][] = new String[1][2];
						int largo[] = new int[2];
						int contador = 0;
						//int Tipo = 0;
						while( rs2.next() ) {

							nombrecui = rs2.getString("nombre");
							apellidocui = rs2.getString("apellidos");

							nuevo[0][0] = nombrecui;
							nuevo[0][1] = apellidocui;
							
							if(contador == 0) {
								largo[0] = 20;
								largo[1] = nuevo[0][0].length() + 20;
								
							}
							contador++;
							misCuidadores.appendText(String.format("%" + largo[0] + "s", nuevo[0][0]));
							misCuidadores.appendText(String.format("%" + largo[1] + "s", nuevo[0][1]+"\n"));
							
						}      
						rs2.close();
						stmt.close();
						//System.out.println(Tipo);
						
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Se ha producido un error ");
					}
					
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				
				
				
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}     

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
}

    	

    

    @FXML
    void cerrarsesion(ActionEvent event) {
    	try {
    		
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_principal.fxml"));
    		
    		MenuPrincipalControllerDB control = new MenuPrincipalControllerDB();
    		
    		loader2.setController(control);

    		Parent root = loader2.load();
    		
    		Scene scene = new Scene(root);
    		Stage stage = new Stage();
    		
    		stage.setScene(scene);
    		stage.show();
    		
    		
			Stage stage2 = (Stage) this.boton_cerrar_sesion.getScene().getWindow();
   	        stage2.close();
    		
    		}
    		catch(Exception e) {
    			e.printStackTrace();
    		}

    }

    @FXML
    void initialize() {
         etiquetaNombrePaciente.setText(LoginDB.nombre);
         Connection conn = null;
 		Statement stmt = null;
 		String sql;
 		try {
 			//STEP 1: Register JDBC driver
 			Class.forName("org.mariadb.jdbc.Driver");
 			//STEP 2: Open a connection
 			try {
 				conn = DriverManager.getConnection(
 						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
 				System.out.println("Connectado a la Base de Datos...");

 				//consulta
 				sql = "SELECT * FROM paciente WHERE paciente.id_P = \""+ LoginDB.id + "\"";

 				System.out.println("sql command: "+ sql);
 				stmt = conn.createStatement();
 				ResultSet rs = stmt.executeQuery( sql );
 				System.out.println(rs);
 				String nombrepac = null;
 				String appellidopac = null;
 				String dnipac=null;
 				String antiguo = null;
 				String nuevo = null;
 				
 				//int Tipo = 0;

 				while( rs.next() ) {

 					nombrepac = rs.getString("nombre");
 					appellidopac = rs.getString("apellidos");
 					dnipac = rs.getString("DNI");

 					antiguo = nuevo;
 					nuevo = antiguo + "\n"+"nombre = " + nombrepac +"\n"+ "Apellido: "+ appellidopac +"\n"+"DNI = " + dnipac  +"\n" ;
 				}       
 				etiquetadatospaciente.setText(nuevo);
 				rs.close();
 				stmt.close();
 				//System.out.println(Tipo);
 				//return Tipo;
 			}catch(Exception e){
 				e.printStackTrace();
 				System.out.println("Se ha producido un error ");
 			}    

 			conn.close();
 		} catch (SQLException se) {   
 			se.printStackTrace();
 		} catch (Exception e) {  
 			e.printStackTrace();
 		} finally {  
 			try {
 				if (stmt != null) {conn.close();}
 			} catch (SQLException se) { }
 			try {
 				if (conn != null) {conn.close();}
 			} catch (SQLException se) { se.printStackTrace();
 			}
 		}
        
        
    }
}
