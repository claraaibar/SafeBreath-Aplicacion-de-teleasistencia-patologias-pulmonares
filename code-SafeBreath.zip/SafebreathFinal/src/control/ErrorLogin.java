package control;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class ErrorLogin {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button volverIniciosesion;

    @FXML
    void iniciarSesionMedico(ActionEvent event) {
    	
//    	Stage registrar = (Stage) volverIniciosesion.getScene().getWindow();
//        registrar.close();
    	try {
    		 
       		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_login.fxml"));
       		
       		LoginDB control = new LoginDB();
       		
       		loader2.setController(control);

       		Parent root = loader2.load();
       		
       		Scene scene = new Scene(root);
       		Stage stage = new Stage();
       		
       		stage.setScene(scene);
       		stage.show();
       		
       		stage.setOnCloseRequest(e -> control.closeWindows());
    		Stage mystage = (Stage) this.volverIniciosesion.getScene().getWindow();
    		mystage.close();
    		
       		}
       		catch(Exception e) {
       			e.printStackTrace();
       		}
    }

    @FXML
    void initialize() {
        assert volverIniciosesion != null : "fx:id=\"volverIniciosesion\" was not injected: check your FXML file 'vista_error_login.fxml'.";

    }
}
