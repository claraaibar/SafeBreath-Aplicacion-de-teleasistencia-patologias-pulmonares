package control;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MenuCuidadorController2 {

//  Database credentials
	static final String USER = "prb_SafeBreath";
	static final String PASS = "camaleon";
	
    @FXML
    private TextField etiquetaNombreCuidador;

    @FXML
    private Button boton_cerrar_sesion;

    @FXML
    private TextField t_valor_SO2;

    @FXML
    private TextField imprimir_oxSangre;

    @FXML
    private TextField t_valor_frec_card;

    @FXML
    private TextField imprimir_frecCard;

    @FXML
    private TextField t_valor_frec_resp;

    @FXML
    private TextField imprimir_frecResp;

    @FXML
    private TextField t_valor_temp;

    @FXML
    private TextField imprimir_temp;

    @FXML
    private Button b_SO2_reg;

    @FXML
    private Button b_frec_card_reg;

    @FXML
    private Button b_reg_frec_resp;

    @FXML
    private Button b_reg_temp;

    @FXML
    private LineChart<String, Double> Grafica_SO2;

    @FXML
    private Button b_graficar_SO2;

    @FXML
    private LineChart<String, Double> grafica_frec_card;

    @FXML
    private Button b_graficar_frec_resp;

    @FXML
    private TextField t_nombre;

    @FXML
    private TextField t_apellidos;

    @FXML
    private TextField t_DNI;

    @FXML
    private TextField t_genero;

    @FXML
    private TextField t_fn;

    @FXML
    private Button boton_volver_menu;

    @FXML
    void cerrarsesion(ActionEvent event) {

    	try {
			//    		
			FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_principal.fxml"));

			MenuPrincipalControllerDB control = new MenuPrincipalControllerDB();

			loader2.setController(control);

			Parent root = loader2.load();

			Scene scene = new Scene(root);
			Stage stage = new Stage();

			stage.setScene(scene);
			stage.show();
			
			Stage stage2 = (Stage) this.t_fn.getScene().getWindow();
   	        stage2.close();
   		


		}
		catch(Exception e) {
			e.printStackTrace();
		}
    	
    }

private void graf_SO2(double parametro, String nombre) {
    	
    	//grafica.getData().clear();
    	
    	Series<String,Double> series = new XYChart.Series<>();
    	series.setName(nombre);
    	
    	series.getData().add(new XYChart.Data<>(nombre,parametro));
    	Grafica_SO2.getData().add(series);
    }

private void graf_frec_card(double parametro, String nombre) {
	
	//grafica.getData().clear();
	
	Series<String,Double> series = new XYChart.Series<>();
	series.setName(nombre);
	
	series.getData().add(new XYChart.Data<>(nombre,parametro));
	grafica_frec_card.getData().add(series);
}
    
    @FXML
    void graficar_SO2(ActionEvent event) {

    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM pulsioximetro JOIN paciente USING (id_P) WHERE paciente.id_P= pulsioximetro.id_P AND 21=pulsioximetro.id_P";
						

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				int frecresppac;
				Timestamp timestamp;
				


				//int ignacioestonto = 0;

				while( rs.next() ) {

					frecresppac = rs.getInt("oxSangre");
					timestamp = rs.getTimestamp("tiempoRegistroP");
					
					System.out.println(frecresppac);	
					System.out.println(timestamp);
					graf_SO2(frecresppac,String.valueOf(timestamp));
					
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			
			
			}
		}
    }

    @FXML
    void graficar_frec_card(ActionEvent event) {

    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM pulsioximetro JOIN paciente USING (id_P) WHERE paciente.id_P= pulsioximetro.id_P AND 21=pulsioximetro.id_P";
						

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				int frecresppac;
				Timestamp timestamp;
				


				//int ignacioestonto = 0;

				while( rs.next() ) {

					frecresppac = rs.getInt("frecCard");
					timestamp = rs.getTimestamp("tiempoRegistroP");
					
					System.out.println(frecresppac);	
					System.out.println("holi");
					System.out.println(timestamp);
					graf_frec_card(frecresppac,String.valueOf(timestamp));
					
				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			
			
			}
		}
    }

    @FXML
    void mostrar_reg_SO2(ActionEvent event) {
    	try {
    	FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_historial_oxSangre.fxml"));
		
		HistorialOxsangreController control = new HistorialOxsangreController();
		
		loader2.setController(control);

		Parent root = loader2.load();
		
		Scene scene = new Scene(root);
		Stage stage = new Stage();
		
		stage.setScene(scene);
		stage.show();
		
		 
	     
		}
		catch(Exception e) {
			e.printStackTrace();
		}
    }

    @FXML
    void mostrar_reg_frec_card(ActionEvent event) {

try {
    		
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_historial_frecResp.fxml"));
    		
    		HistorialFrecrespController control = new HistorialFrecrespController();
    		
    		loader2.setController(control);

    		Parent root = loader2.load();
    		
    		Scene scene = new Scene(root);
    		Stage stage = new Stage();
    		
    		stage.setScene(scene);
    		stage.show();
    		
    		 
    	     
    		}
    		catch(Exception e) {
    			e.printStackTrace();
    		}
    }

    @FXML
    void mostrar_reg_frec_resp(ActionEvent event) {

try {
    		
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_historial_frecResp.fxml"));
    		
    		HistorialFrecrespController control = new HistorialFrecrespController();
    		
    		loader2.setController(control);

    		Parent root = loader2.load();
    		
    		Scene scene = new Scene(root);
    		Stage stage = new Stage();
    		
    		stage.setScene(scene);
    		stage.show();
    		
    		 
    	     
    		}
    		catch(Exception e) {
    			e.printStackTrace();
    		}
    }

    @FXML
    void mostrar_reg_temp(ActionEvent event) {

try {
    		
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_historial_temperatura.fxml"));
    		
    		historial_temp_controller control = new historial_temp_controller();
    		
    		loader2.setController(control);

    		Parent root = loader2.load();
    		
    		Scene scene = new Scene(root);
    		Stage stage = new Stage();
    		
    		stage.setScene(scene);
    		stage.show();
    		
    		 
    	     
    		}
    		catch(Exception e) {
    			e.printStackTrace();
    		}
    }

    @FXML
    void volver_menu(ActionEvent event) {

try {
    		
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_cuidador.fxml"));
    		
    		MenuCuidadorController control = new MenuCuidadorController();
    		
    		loader2.setController(control);

    		Parent root = loader2.load();
    		
    		Scene scene = new Scene(root);
    		Stage stage = new Stage();
    		
    		stage.setScene(scene);
    		stage.show();
    		
    		 
    	     
    		}
    		catch(Exception e) {
    			e.printStackTrace();
    		}
    }

    @FXML
    void initialize() {
    	etiquetaNombreCuidador.setText(LoginDB.nombre);
    	t_nombre.setText(MenuCuidadorController.usuario[0]);
        t_apellidos.setText(MenuCuidadorController.usuario[1]);
        t_DNI.setText(MenuCuidadorController.usuario[2]);
        t_genero.setText(MenuCuidadorController.usuario[3]);
        t_fn.setText(MenuCuidadorController.usuario[4]);

    }
    
    public Object closeWindows() {
		// TODO Auto-generated method stub
		return null;
	}
    
}
