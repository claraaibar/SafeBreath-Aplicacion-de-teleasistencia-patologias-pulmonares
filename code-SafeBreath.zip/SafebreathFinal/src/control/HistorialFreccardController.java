package control;


import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.time.LocalDate;
import java.util.Vector;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.sun.javafx.scene.control.skin.FXVK.Type;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.stage.Stage;
import model.Paciente;


import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;


public class HistorialFreccardController {

//  Database credentials
	static final String USER = "prb_SafeBreath";
	static final String PASS = "camaleon";


    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea text_imprimir_frecCard;

    @FXML
    private LineChart<String, Double> graf_frecCard;

    @FXML
    void mostrar_frecCard(ActionEvent event) {
    
    	 Connection conn = null;
     	Statement stmt = null;
     	String sql;
     	try {
     		//STEP 1: Register JDBC driver
     		Class.forName("org.mariadb.jdbc.Driver");
     		//STEP 2: Open a connection
     		try {
     			conn = DriverManager.getConnection(
     					"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
     			System.out.println("Connectado a la Base de Datos...");

     			//consulta
     			sql = "SELECT * FROM pulsioximetro JOIN paciente USING (id_P) WHERE paciente.id_P= pulsioximetro.id_P AND 21=pulsioximetro.id_P";

     			System.out.println("sql command: "+ sql);
     			stmt = conn.createStatement();
     			ResultSet rs = stmt.executeQuery( sql );
     			System.out.println(rs);
     			int frecCard = 0;
     			Timestamp timestamp = null;
     			String antiguo = null;
     			String nuevo = null;
     			
     			
     			
     			//int Tipo = 0;

     			while( rs.next() ) {

     				frecCard = rs.getInt("frecCard");
     				timestamp = rs.getTimestamp("tiempoRegistroP");

     				antiguo = nuevo;
     				nuevo = antiguo  + frecCard +"\t" + "\t"+ timestamp +"\n" ;
     			}       
     			text_imprimir_frecCard.setText(nuevo);
     			rs.close();
     			stmt.close();
     			//System.out.println(Tipo);
     			//return Tipo;
     		}catch(Exception e){
     			e.printStackTrace();
     			System.out.println("Se ha producido un error ");
     		}    

     		conn.close();
     	} catch (SQLException se) {   
     		se.printStackTrace();
     	} catch (Exception e) {  
     		e.printStackTrace();
     	} finally {  
     		try {
     			if (stmt != null) {conn.close();}
     		} catch (SQLException se) { }
     		try {
     			if (conn != null) {conn.close();}
     		} catch (SQLException se) { se.printStackTrace();
     		}
     	}
     	return;
    
    }
  private void graf_frecCard(double parametro, String nombre) {
      	
      	//grafica.getData().clear();
      	
      	Series<String,Double> series = new XYChart.Series<>();
      	series.setName(nombre);
      	
      	series.getData().add(new XYChart.Data<>(nombre,parametro));
      	graf_frecCard.getData().add(series);
      }
    @FXML
    void mostrar_frec_card2(ActionEvent event) {
     	Connection conn = null;
    		Statement stmt = null;
    		String sql;
    		try {
    			//STEP 1: Register JDBC driver
    			Class.forName("org.mariadb.jdbc.Driver");
    			//STEP 2: Open a connection
    			try {
    				conn = DriverManager.getConnection(
    						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
    				System.out.println("Connectado a la Base de Datos...");

    				//consulta
    				sql = "SELECT * FROM pulsioximetro JOIN paciente USING (id_P) WHERE paciente.id_P= pulsioximetro.id_P AND 21=pulsioximetro.id_P";
    						

    				System.out.println("sql command: "+ sql);
    				stmt = conn.createStatement();
    				ResultSet rs = stmt.executeQuery( sql );
    				System.out.println(rs);
    				int frecCard;
    				Timestamp tiempo;

    			

    				while( rs.next() ) {

    					frecCard = rs.getInt("frecCard");
    					tiempo = rs.getTimestamp("tiempoRegistroP");
    					System.out.println(frecCard);
    					
    					System.out.println(tiempo);
    					graf_frecCard(frecCard,String.valueOf(tiempo));
    					
    				}       
    				rs.close();
    				stmt.close();
    				//System.out.println(Tipo);
    			}catch(Exception e){
    				e.printStackTrace();
    				System.out.println("Se ha producido un error ");
    			}    

    			conn.close();
    		} catch (SQLException se) {   
    			se.printStackTrace();
    		} catch (Exception e) {  
    			e.printStackTrace();
    		} finally {  
    			try {
    				if (stmt != null) {conn.close();}
    			} catch (SQLException se) { }
    			try {
    				if (conn != null) {conn.close();}
    			} catch (SQLException se) { se.printStackTrace();
    			
    			
    			}
    		}

    }
    @FXML
    void initialize() {
        assert text_imprimir_frecCard != null : "fx:id=\"text_imprimir_frecCard\" was not injected: check your FXML file 'vista_historial_frecCard.fxml'.";
        assert graf_frecCard != null : "fx:id=\"graf_frecCard\" was not injected: check your FXML file 'vista_historial_frecCard.fxml'.";

    }
}
