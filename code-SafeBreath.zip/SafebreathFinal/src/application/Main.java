package application;



import control.MenuPrincipalControllerDB;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.Db;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/vista_menu_principal.fxml"));
			
			MenuPrincipalControllerDB control = new MenuPrincipalControllerDB();
			
			loader.setController(control);

			Parent root = loader.load();
			
			primaryStage.setScene(new Scene(root));
			primaryStage.show();
			
		
		
			//Db.Mostrar_pacientes_bajocuidado(2);
		//Db.Mostrar_medico(14);
//		Db.Mostrar_miscuidadores(1);
		
		
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
		
	}
}
