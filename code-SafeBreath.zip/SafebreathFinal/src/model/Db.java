package model;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;


/*
 * Conector JDBC para MariaDB
 * https://mariadb.com/kb/en/about-mariadb-connector-j/
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import control.ErrorLogin;
import control.LoginDB;
import control.MenuCuidadorController;
import control.MenuMedicoController;
import control.MenuPacienteController;
import control.MenuPrincipalControllerDB;

import java.sql.ResultSet;
import java.sql.SQLException;

public class Db {

	//  Database credentials
	static final String USER = "prb_SafeBreath";
	static final String PASS = "camaleon";
	public static int tipoM;

	
	public static String nombre(String u, int tipo) {
		String  nombre = null;
		Connection conn = null;
		Statement stmt = null;
		String sql;
		
			if (tipo == 1) {
				try {
					//STEP 1: Register JDBC driver
					Class.forName("org.mariadb.jdbc.Driver");

					conn = DriverManager.getConnection(
							"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

					//STEP 5: Realizando una consulta
					sql = "SELECT nombre FROM paciente WHERE paciente.usuario = \""+ u +" \"";
					System.out.println("sql Select: "+sql);
					stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery( sql );
					while ( rs.next() ) {
						nombre = rs.getString("nombre");
					}
					rs.close();
					stmt.close();

					//STEP 6: Cerrando conexion.
					conn.close();

				} catch (SQLException se) {
					//Handle errors for JDBC
					se.printStackTrace();
				} catch (Exception e) {
					//Handle errors for Class.forName
					e.printStackTrace();
				}
			} if (tipo == 2) {
				try {
					//STEP 1: Register JDBC driver
					Class.forName("org.mariadb.jdbc.Driver");

					conn = DriverManager.getConnection(
							"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

					//STEP 5: Realizando una consulta
					sql = "SELECT nombre FROM medico WHERE medico.usuario = \""+ u +" \"";
					System.out.println("sql Select: "+sql);
					stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery( sql );
					while ( rs.next() ) {
						nombre = rs.getString("nombre");
					}
					rs.close();
					stmt.close();

					//STEP 6: Cerrando conexion.
					conn.close();

				} catch (SQLException se) {
					//Handle errors for JDBC
					se.printStackTrace();
				} catch (Exception e) {
					//Handle errors for Class.forName
					e.printStackTrace();
				}
			} if (tipo == 3) {
				try {
					//STEP 1: Register JDBC driver
					Class.forName("org.mariadb.jdbc.Driver");

					conn = DriverManager.getConnection(
							"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

					//STEP 5: Realizando una consulta
					sql = "SELECT nombre FROM cuidador WHERE cuidador.usuario = \""+ u +" \"";
					System.out.println("sql Select: "+sql);
					stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery( sql );
					while ( rs.next() ) {
						nombre = rs.getString("nombre");
					}
					rs.close();
					stmt.close();

					//STEP 6: Cerrando conexion.
					conn.close();

				} catch (SQLException se) {
					//Handle errors for JDBC
					se.printStackTrace();
				} catch (Exception e) {
					//Handle errors for Class.forName
					e.printStackTrace();
				}
			}

			return nombre;
	}
	
	public static String[] usuario(String dni) {
		
		String[] completo= new String[5];
		String  nombre = null;
		String  apellido = null;
		String  genero = null;
		String  fn = null;
		String  DNI = null;
		Connection conn = null;
		Statement stmt = null;
		String sql;
		
			
			try {
				//STEP 1: Register JDBC driver
				Class.forName("org.mariadb.jdbc.Driver");

				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

				//STEP 5: Realizando una consulta
				sql = "SELECT nombre, apellidos, usuario, tlf, genero, fn, DNI FROM paciente WHERE paciente.DNI = \""+ dni +" \"";
				System.out.println("sql Select: "+sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				while ( rs.next() ) {
					nombre = rs.getString("nombre");
					apellido = rs.getString("apellidos");
					genero = rs.getString("genero");
					fn = rs.getString("fn");
					DNI = rs.getString("DNI");

				}
				rs.close();
				stmt.close();

				//STEP 6: Cerrando conexion.
				conn.close();

			} catch (SQLException se) {
				//Handle errors for JDBC
				se.printStackTrace();
			} catch (Exception e) {
				//Handle errors for Class.forName
				e.printStackTrace();
			}
			
			completo[0] = nombre;
			completo[1] = apellido;
			completo[2] = DNI;
			completo[3] = genero;
			completo[4] = fn;
		
		
		
		
		
		return completo;
	}
	
	public void conectar () {
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");

			//STEP 2: Open a connection
			System.out.println("Connecting to a selected database...");

			conn = DriverManager.getConnection(
					"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
			System.out.println("Connectado a la Base de Datos...");

			//STEP 4: Insertando un valor.

			sql = "Insert into medico(nombre,apellidos,usuario,tlf,genero,fn,DNI,contrasena) values('Maria','Marquez','MM',45678,'Mujer','27-06-2002','345678K','1234');";
			System.out.println("sql Insert: "+sql);
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);  
			stmt.close();


			//STEP 5: Realizando una consulta
			sql = "SELECT id_M, nombre, apellidos, usuario, tlf, genero, fn, DNI FROM medico";
			System.out.println("sql Select: "+sql);
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery( sql );
			while ( rs.next() ) {
				int id = rs.getInt("id_M");
				String  nombre = rs.getString("nombre");
				String  apellido = rs.getString("apellidos");
				String  usuario = rs.getString("usuario");
				int tlf = rs.getInt("tlf");
				String  genero = rs.getString("genero");
				String  fn = rs.getString("fn");
				String  DNI = rs.getString("DNI");
				System.out.print( nombre );

			}
			rs.close();
			stmt.close();

			//STEP 6: Cerrando conexion.
			conn.close();

		} catch (SQLException se) {
			//Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			//Handle errors for Class.forName
			e.printStackTrace();
		} 
		finally {
			//finally block used to close resources
			try {
				if (stmt != null) {
					conn.close();
				}
			} catch (SQLException se) {
			}// do nothing
			try {
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException se) {
				se.printStackTrace();
			}//end finally try
		}//end try

		System.out.println("Fin Codigo!");
	}

	public static int buscarM(String dni, int id) {

		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

				//STEP 3: Realizando una consulta y busca al usuario y contrasena en cuestion
				sql = "SELECT * FROM paciente WHERE paciente.DNI = \""+ dni + "\" AND paciente.id_M = \"" +id+"\"";

				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
			 int idP = 0;
				while ( rs.next() ) {
                   	idP = rs.getInt("id_P");  //se coge el tipo de usuario para saber q menu abrir
                   }
				
				
				

				return idP;          //te devuelve el id lo cual nos viene bn para lo de mostrar mis pacientes
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			} 
			conn.close();
		} catch (SQLException se) {  
			se.printStackTrace();
		} catch (Exception e) {   
			e.printStackTrace();
		} finally { 
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }// do nothing
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}//end finally try
		}//end try            
		System.out.println("Fin Codigo!");
		return 0;
	}
	
	public static int buscarC(String dni, int id) {

		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

				//STEP 3: Realizando una consulta y busca al usuario y contrasena en cuestion
				sql = "SELECT id_P FROM paciente WHERE paciente.DNI = \""+ dni + "\"";

				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
			 int idP = 0;
			 int validado = 0;
				while ( rs.next() ) {
                   	idP = rs.getInt("id_P");  //se coge el tipo de usuario para saber q menu abrir
                   	
                   	try {
						
						conn = DriverManager.getConnection(
								"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
						//consulta
						sql = "SELECT * FROM Supervisa WHERE Supervisa.id_C='"+id+"' AND Supervisa.id_P =\"" +idP+"\"";

						stmt = conn.createStatement();
						ResultSet rs2 = stmt.executeQuery( sql );


						while( rs2.next() ) {

						validado =1;
						}       
						
						rs2.close();
						stmt.close();
						//System.out.println(Tipo);
						
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Se ha producido un error ");
					}
                   }
				return validado;
				
        //te devuelve el id lo cual nos viene bn para lo de mostrar mis pacientes
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			} 
			conn.close();
		} catch (SQLException se) {  
			se.printStackTrace();
		} catch (Exception e) {   
			e.printStackTrace();
		} finally { 
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }// do nothing
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}//end finally try
		}//end try            
		System.out.println("Fin Codigo!");
		return 0;
	}
	
	public static int crearMedico (String nombre, String apellido, String dni, String usuario, String contrasena, String fechan, String genero, int tlf) {
		Connection conn = null;
		Statement stmt = null;
		String sql;
		String sql2;
		int validado = 0;
		String telefono = String.valueOf(tlf);
		tipoM = 2;
		
		if (nombre != null && apellido != null && dni.length() == 9 && usuario != null && contrasena != null && fechan != null && genero != null && telefono.length() == 9) {
			
			try {
				Class.forName("org.mariadb.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");
				

				sql = "Insert into Login(usuario, contrasena, tipo) values('"+usuario+"','"+contrasena+"','"+tipoM+"');"; //el first es del valor de la tabla first name"
				System.out.println("sql Insert: "+sql);
				stmt = conn.createStatement(); 
				stmt.executeUpdate(sql);  
				stmt.close();

				sql2 = "Insert into medico(nombre, apellidos, usuario, tlf, genero, fn, DNI, contrasena, tipo) values('"+nombre+"','"+apellido+"','"+usuario+"','"+tlf+"','"+genero+"','"+fechan+"','"+dni+"','"+contrasena+"','"+tipoM+"');";
				System.out.println("sql Insert: "+sql2);
				stmt = conn.createStatement(); 
				stmt.executeUpdate(sql2);  
				stmt.close();

				validado = 1;
				
				return validado;
				
			} catch (SQLException se) {
				//Handle errors for JDBC
				se.printStackTrace();
			} catch (Exception e) {
				//Handle errors for Class.forName
				e.printStackTrace();
			} finally {
				//finally block used to close resources
				try {
					if (stmt != null) {
						conn.close();
					}
				} catch (SQLException se) {
				}// do nothing
				try {
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException se) {
					se.printStackTrace();
				}//end finally try
			}//end try
			
		}
		
		
		return validado;
	}


	public static int crearPacientes (String nombre, String apellido, String dni, String usuario, String contrasena, String fechan, String genero, int tlf, int idm) {
		
		Connection conn = null;
		Statement stmt = null;
		String sql;
		String sql2;
		int validado = 0;
		String telefono = String.valueOf(tlf);

		tipoM = 1;
		if (nombre != null && apellido != null && dni.length() == 9 && usuario != null && contrasena != null && fechan != null && genero != null && telefono.length() == 9) {
			
			try {
				Class.forName("org.mariadb.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");
				

				sql = "Insert into Login(usuario, contrasena, tipo) values('"+usuario+"','"+contrasena+"','"+tipoM+"');"; //el first es del valor de la tabla first name"
				System.out.println("sql Insert: "+sql);
				stmt = conn.createStatement(); 
				stmt.executeUpdate(sql);  
				stmt.close();

				sql2 = "Insert into paciente(nombre, apellidos, usuario, tlf, genero, fn, DNI, id_M, contrasena, tipo) values('"+nombre+"','"+apellido+"','"+usuario+"','"+tlf+"','"+genero+"','"+fechan+"','"+dni+"','"+idm+"','"+contrasena+"','"+tipoM+"');";
				System.out.println("sql Insert: "+sql2);
				stmt = conn.createStatement(); 
				stmt.executeUpdate(sql2);  
				stmt.close();

				validado = 1;
				
				return validado;
				
			} catch (SQLException se) {
				//Handle errors for JDBC
				se.printStackTrace();
			} catch (Exception e) {
				//Handle errors for Class.forName
				e.printStackTrace();
			} finally {
				//finally block used to close resources
				try {
					if (stmt != null) {
						conn.close();
					}
				} catch (SQLException se) {
				}// do nothing
				try {
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException se) {
					se.printStackTrace();
				}//end finally try
			}//end try
			
		}
		
		
		return validado;
	}

	public static int crearCuidador (String nombre, String apellido, String dni, String usuario, String contrasena, String fechan, String genero, int tlf) {
		
		Connection conn = null;
		Statement stmt = null;
		String sql;
		String sql2;
		int validado = 0;
		String telefono = String.valueOf(tlf);

		tipoM = 3;
		if (nombre != null && apellido != null && dni.length() == 9 && usuario != null && contrasena != null && fechan != null && genero != null && telefono.length() == 9) {
			
			try {
				Class.forName("org.mariadb.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");
				

				sql = "Insert into Login(usuario, contrasena, tipo) values('"+usuario+"','"+contrasena+"','"+tipoM+"');"; //el first es del valor de la tabla first name"
				System.out.println("sql Insert: "+sql);
				stmt = conn.createStatement(); 
				stmt.executeUpdate(sql);  
				stmt.close();

				sql2 = "Insert into cuidador(nombre, apellidos, usuario, tlf, genero, fn, DNI, contrasena, tipo) values('"+nombre+"','"+apellido+"','"+usuario+"','"+tlf+"','"+genero+"','"+fechan+"','"+dni+"','"+contrasena+"','"+tipoM+"');";
				System.out.println("sql Insert: "+sql2);
				stmt = conn.createStatement(); 
				stmt.executeUpdate(sql2);  
				stmt.close();

				validado = 1;
				
				return validado;
				
			} catch (SQLException se) {
				//Handle errors for JDBC
				se.printStackTrace();
			} catch (Exception e) {
				//Handle errors for Class.forName
				e.printStackTrace();
			} finally {
				//finally block used to close resources
				try {
					if (stmt != null) {
						conn.close();
					}
				} catch (SQLException se) {
				}// do nothing
				try {
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException se) {
					se.printStackTrace();
				}//end finally try
			}//end try
			
		}
		
		
		return validado;
	}

	public static int login(String usuario, String contrasena) {

		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

				//STEP 3: Realizando una consulta y busca al usuario y contrasena en cuestion
				sql = "SELECT * FROM Login WHERE Login.usuario = \""+ usuario + "\" AND Login.contrasena = \"" +contrasena+"\"";

				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
			 int tipo = 0;
				while ( rs.next() ) {
                   	tipo = rs.getInt("tipo");  //se coge el tipo de usuario para saber q menu abrir
                   }
				
				
				

				return tipo;          //te devuelve el id lo cual nos viene bn para lo de mostrar mis pacientes
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			} 
			conn.close();
		} catch (SQLException se) {  
			se.printStackTrace();
		} catch (Exception e) {   
			e.printStackTrace();
		} finally { 
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }// do nothing
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}//end finally try
		}//end try            
		System.out.println("Fin Codigo!");
		return 8;
	}
	public static Integer Mostrar_sensores(int id_P) {
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql =  "SELECT co, frecuresp, oxsangre,freccard,Temperatura ,tiemporegistroC,tiemporegistroF,tiemporegistroP,tiemporegistroT,id_sensorc,id_sensorf,id_sensorP,id_sensort FROM CO2 join FrecResp join Temperatura join pulsioximetro WHERE CO2.id_P= '"+ id_P + "' AnD FrecResp.id_P= '"+ id_P + "' AND Temperatura.id_P= '"+ id_P + "' AND pulsioximetro.id_P= '"+ id_P + "'";




				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				//  System.out.println(rs);
				String co;
				String frecuresp;
				String oxsangre;
				String freccard;
				String Temperatura;
				int tiemporegistroC;
				int tiemporegistroF;
				int tiemporegistroP;
				int tiemporegistroT;
				int id_sensorc;
				int id_sensorf;
				int id_sensorP;
				int id_sensort;

				int Tipo = 0;

				while( rs.next() ) {

					co = rs.getString("co");
					frecuresp = rs.getString("frecuresp");
					oxsangre= rs.getString("oxsangre");
					freccard= rs.getString("freccard");
					Temperatura= rs.getString("temperatura");
					tiemporegistroC = rs.getInt("tiemporegistroC");
					tiemporegistroF =rs.getInt("tiemporegistroF");
					tiemporegistroP =rs.getInt("tiemporegistroP");
					tiemporegistroT =rs.getInt("tiemporegistroT");
					id_sensorc= rs.getInt("id_sensorc");
					id_sensorf = rs.getInt("id_sensorf");
					id_sensorP =rs.getInt("id_sensorP");
					id_sensort= rs.getInt("id_sensort");

					System.out.print( 

							"ID sensor : " +id_sensorc+" \n"+
									"CO2 = "+co+" \n"+
									"Tiempo de registro = "+tiemporegistroC+" \n"+" \n"+

	                    		       "ID sensor : " +id_sensorf+" \n"+
	                    		       "Frecuencia respiratoria = "+frecuresp +" \n"+
	                    		       "Tiempo de registro = "+tiemporegistroF+" \n"+" \n"+

	                    		       "ID sensor : " + id_sensorP+" \n"+
	                    		       "Oxigeno en sangre = "+oxsangre+" \n"+
	                    		       "Frecuencia cardiaca = " + freccard+" \n"+
	                    		       "Tiempo de registro = "+  tiemporegistroP+" \n"+" \n"+

	                    		       "ID sensor : " + id_sensort+" \n"+
	                    		       "Temperatura = "+ Temperatura+" \n"+
	                    		       "Tiempo de registro = "+ tiemporegistroT+" \n"+" \n");


				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				return Tipo;
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
		return null;
	} 
	public static Integer Mostrar_pacientes(int id_medico) {
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM paciente WHERE paciente.id_M = \""+ id_medico + "\"";

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String nombrepac;
				String appellidopac;
				String generopac;
				String fechanac;
				//int Tipo = 0;

				while( rs.next() ) {

					nombrepac = rs.getString("nombre");
					appellidopac = rs.getString("apellidos");
					generopac = rs.getString("genero");
					fechanac = rs.getString("fn");

					System.out.print( "nombre = " + nombrepac +" " + appellidopac +" genero = " + generopac +" fn = " + fechanac +"\n");


				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				//return Tipo;
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
		return null;
	}
	public static Integer Mostrar_medico(int id_P) {
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM medico JOIN paciente USING (id_M) WHERE id_P = '"+ id_P + "' AND id_M = paciente.id_M";

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String nombremed;
				String appellidomed;

				int Tipo = 0;

				while( rs.next() ) {

					nombremed = rs.getString("nombre");
					appellidomed = rs.getString("apellidos");


					System.out.print( " Tu m�dico = " + nombremed +" " + appellidomed +" \n");


				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				return Tipo;
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
		return null;
	}

	public static Integer Mostrar_pacientes_bajocuidado(int id_cuidador) {
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM paciente JOIN Supervisa USING (id_P) WHERE paciente.id_P= Supervisa.id_P AND '"+ id_cuidador +"' = Supervisa.id_C";

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String nombrepac;
				String appellidopac;
				String generopac;
				String fechanac;
				//int Tipo = 0;

				while( rs.next() ) {

					nombrepac = rs.getString("nombre");
					appellidopac = rs.getString("apellidos");
					generopac = rs.getString("genero");
					fechanac = rs.getString("fn");

					System.out.print( "nombre = " + nombrepac +" " + appellidopac +" genero = " + generopac +" fn = " + fechanac +"\n");


				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				//return Tipo;
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
		return null;
	}

	public static Integer Mostrar_miscuidadores(int id_paciente) {
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM cuidador JOIN Supervisa USING (id_C) WHERE cuidador.id_C= Supervisa.id_C AND '"+id_paciente+"'= Supervisa.id_P;";

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String nombrecuid;
				String appellidocuid;

				int Tipo = 0;

				while( rs.next() ) {

					nombrecuid = rs.getString("nombre");
					appellidocuid = rs.getString("apellidos");


					System.out.print( " Cuidador/es = " + nombrecuid +" " + appellidocuid +" \n");


				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				return Tipo;
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
		return null;
	}

	public static Integer Buscar_Paciente(int id_P) {
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM paciente  WHERE id_P = '"+ id_P + "'";

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String nombrepac;
				String appellidopac;

				int Tipo = 0;

				while( rs.next() ) {

					nombrepac = rs.getString("nombre");
					appellidopac = rs.getString("apellidos");


					System.out.print( " Paciente = " + nombrepac +" " + appellidopac +" \n");


				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				return Tipo;
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
		return null;
	}
	public static Integer Buscar_Medico(int id_M) {
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM medico  WHERE id_M = '"+ id_M + "'";

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String nombremed;
				String appellidomed;

				int Tipo = 0;

				while( rs.next() ) {

					nombremed = rs.getString("nombre");
					appellidomed = rs.getString("apellidos");


					System.out.print( " Medico = " + nombremed +" " + appellidomed +" \n");


				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				return Tipo;
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
		return null;
	}
	public static Integer Buscar_Cuidador(int id_C) {
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
				System.out.println("Connectado a la Base de Datos...");

				//consulta
				sql = "SELECT * FROM cuidador  WHERE id_C = '"+ id_C + "'";

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String nombrecuid;
				String appellidocuid;

				int Tipo = 0;

				while( rs.next() ) {

					nombrecuid = rs.getString("nombre");
					appellidocuid = rs.getString("apellidos");


					System.out.print( " Cuidador = " + nombrecuid +" " + appellidocuid +" \n");


				}       
				rs.close();
				stmt.close();
				//System.out.println(Tipo);
				return Tipo;
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			}    

			conn.close();
		} catch (SQLException se) {   
			se.printStackTrace();
		} catch (Exception e) {  
			e.printStackTrace();
		} finally {  
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}
		}
		return null;
	}
	public static void borrar(String usuario, String tabla) {



		Connection conn = null;
		Statement stmt = null;
		String sql;
		String sql2;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
			//STEP 2: Open a connection
			try {
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

				//STEP 3: Realizando el borrado
				sql = "DELETE FROM Login WHERE Login.usuario='"+usuario+"';";      		//Se borra el usuario de Login
				sql2= "DELETE FROM "+tabla+" WHERE "+tabla+".usuario='"+usuario+"';";	//Se borra el usuario de la tabla a 
				//la que corresponda. ej. medico

				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );

				stmt = conn.createStatement();
				rs = stmt.executeQuery( sql2 );

				/*if (rs.next()) {							Todavia tengo que solucionar esto pero la funcion borra perfectamente
	                    	   System.out.print("se ha borrado");
	                       } else {
	                    	   System.out.print("no se ha borrado");
	                       }
				 */

				rs.close();
				stmt.close();
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Se ha producido un error ");
			} 
			conn.close();
		} catch (SQLException se) {  
			se.printStackTrace();
		} catch (Exception e) {   
			e.printStackTrace();
		} finally { 
			try {
				if (stmt != null) {conn.close();}
			} catch (SQLException se) { }// do nothing
			try {
				if (conn != null) {conn.close();}
			} catch (SQLException se) { se.printStackTrace();
			}//end finally try
		}//end try 
	}

    	public static void asignar_cuidador(String dniP, String dniC) {
    	Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			//STEP 1: Register JDBC driver
			Class.forName("org.mariadb.jdbc.Driver");
				conn = DriverManager.getConnection(
						"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

				//consulta
				sql = "SELECT id_P FROM paciente WHERE paciente.id_P = \""+ dniP + "\"";

				System.out.println("sql command: "+ sql);
				stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery( sql );
				System.out.println(rs);
				String idP = null;
				while( rs.next() ) {

					idP = rs.getString("id_P");
				}
				if(idP != null) {
					
					try {
						
						Class.forName("org.mariadb.jdbc.Driver");
						conn = DriverManager.getConnection(
								"jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);

						//consulta
						sql = "SELECT id_C FROM paciente WHERE cuidador.id_C = \""+ dniC + "\"";

						System.out.println("sql command: "+ sql);
						stmt = conn.createStatement();
						rs = stmt.executeQuery( sql );
						System.out.println(rs);
						String idC = null;
						while( rs.next() ) {

							idC = rs.getString("id_C");
						}
						if (idC != null) {
							
							try {
								Class.forName("org.mariadb.jdbc.Driver");
								conn = DriverManager.getConnection("jdbc:mariadb://195.235.211.197/prbSafeBreath", USER, PASS);
								System.out.println("Connectado a la Base de Datos...");
								

								sql = "Insert into Supervisa(id_P, id_C) values('"+idP+"','"+idC+"');"; //el first es del valor de la tabla first name"
								System.out.println("sql Insert: "+sql);
								stmt = conn.createStatement(); 
								stmt.executeUpdate(sql);  
								stmt.close();
								
							} catch (SQLException se) {
								//Handle errors for JDBC
								se.printStackTrace();
							} catch (Exception e) {
								//Handle errors for Class.forName
								e.printStackTrace();
							}
							
						}
						
						
					       
					rs.close();
					stmt.close();
					//System.out.println(Tipo);
					//return Tipo;
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("Se ha producido un error ");
				}
					}
				} catch(Exception e){
						e.printStackTrace();
						System.out.println("Se ha producido un error ");
					}
					
    	}


	}


//a
