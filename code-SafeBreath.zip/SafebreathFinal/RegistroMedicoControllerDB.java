package control;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import model.Db;

public class RegistroMedicoControllerDB {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button boton_registro_medico;

    @FXML
    private ChoiceBox<String> choice_genero_medico;

    @FXML
    private DatePicker date_fn_medico;

    @FXML
    private TextField text_DNI_medico;

    @FXML
    private TextField text_apellidos_medico;

    @FXML
    private TextField text_contrasena_medico;

    @FXML
    private TextField text_nombre_medico;

    @FXML
    private TextField text_tlf_medico;

    @FXML
    private TextField text_usuario_medico;

    @FXML
    private Button boton_cancelar;

    @FXML
    void registrar_medioc(ActionEvent event) {
    	
    	String nombre = text_nombre_medico.getText();;
    	String apellidos = text_apellidos_medico.getText();
    	String DNI = text_DNI_medico.getText();
    	String usuario = text_usuario_medico.getText();
    	String contrasena = text_contrasena_medico.getText();
    	String genero = choice_genero_medico.getValue();
    	String tlf = text_tlf_medico.getText();
    	int validado = 0;
    	
    	int telefono = 0;
    	if (tlf.equals("")) {
    	} else {
    		for (int i = 0; i < tlf.length(); i++) { 
    			if (Character.isDigit(tlf.charAt(i))){
    		telefono = Integer.parseInt(tlf);
    		}
    	}
    		
    	}
    	LocalDate fn = date_fn_medico.getValue();
    	String fechan = null;
    	
    	if (tlf.equals("")) {
    	} else {
    		fechan = fn.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    	}
    	validado = Db.crearMedico(nombre, apellidos, DNI, usuario, contrasena, fechan, genero, telefono);
    	
    	if (validado == 1) {
    		
    		try {
         		 
           		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_menu_principal.fxml"));
           		
           		MenuPrincipalControllerDB control = new MenuPrincipalControllerDB();
           		
           		loader2.setController(control);

           		Parent root = loader2.load();
           		
           		Scene scene = new Scene(root);
           		Stage stage = new Stage();
           		
           		stage.setScene(scene);
           		stage.show();
           		
           		Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
	    		Stage stage2 = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
	    		stage2.close();
        		
           		}
           		catch(Exception e) {
           			e.printStackTrace();
           		}
    	} else {
    		
    		try {
    		FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/view/vista_error_registro.fxml"));
       		
       		ErrorRegistro control = new ErrorRegistro();
       		
       		loader2.setController(control);

       		Parent root = loader2.load();
       		
       		Scene scene = new Scene(root);
       		Stage stage = new Stage();
       		
       		stage.setScene(scene);
       		stage.show();
       		
       		Node source = (Node) event.getSource();     //Me devuelve el elemento al que hice click
    		Stage stage2 = (Stage) source.getScene().getWindow();    //Me devuelve la ventana donde se encuentra el elemento
    		stage2.close();
    		
       		}
       		catch(Exception e) {
       			e.printStackTrace();
       		}
    	}
    	


    }

    
    @FXML
    void cancelar(ActionEvent event) {
    	try {
			//    		
    		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/vista_menu_principal.fxml"));
			
			MenuPrincipalControllerDB control = new MenuPrincipalControllerDB();	

			loader.setController(control);

			Parent root = loader.load();

			Scene scene = new Scene(root);
			Stage stage = new Stage();

			stage.setScene(scene);
			stage.show();
			
			Stage stage2 = (Stage) this.boton_cancelar.getScene().getWindow();
   	        stage2.close();
   		


		}
		catch(Exception e) {
			e.printStackTrace();
		}	
    }
    
    @FXML
    void initialize() {
    	
    	  ObservableList<String> genero = FXCollections.observableArrayList("masculino","femenino");
          choice_genero_medico.setItems(genero);

    }

	public Object closeWindows() {
		// TODO Auto-generated method stub
		return null;
	}

}

